import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface SolicitanteInfo {
  numeroPersonal: string;
  nombreCompleto: string;
}

export interface BienItem {
  inventario: string;
  descripcion: string;
  valor: string;
  tarjeta: string;
  ubicacion: string;
  estado?: string;
  procedencia?: string;
  renglon?: string;
  responsableOriginal?: string;
  personalOriginal?: string;
  fueraDeCargo?: boolean;
}

export function generateSolicitudPDFBlob(
  solicitante: SolicitanteInfo,
  bienes: BienItem[],
  correlativo: string,
  emblemBase64?: string
): { doc: jsPDF; fileName: string; blob: Blob; base64: string } {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'letter',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const fecha = new Date().toLocaleDateString('es-GT', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Top header styling
  // University Green Banner
  doc.setFillColor(0, 86, 91); // #00565b
  doc.rect(0, 0, pageWidth, 24, 'F');

  // Accent Gold Line
  doc.setFillColor(217, 119, 6); // #d97706
  doc.rect(0, 24, pageWidth, 2, 'F');

  // University Header Text
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('UNIVERSIDAD DE SAN CARLOS DE GUATEMALA', pageWidth / 2, 9, { align: 'center' });
  
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('FACULTAD DE AGRONOMÍA · UNIDAD DE INVENTARIO', pageWidth / 2, 15, { align: 'center' });
  doc.setFontSize(8);
  doc.text('Ciudad Universitaria, Zona 12, Ciudad de Guatemala', pageWidth / 2, 20, { align: 'center' });

  // Document Title Box
  let y = 34;
  doc.setTextColor(15, 23, 42); // slate-900
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('SOLICITUD DE PROCESO DE BAJAS DE INVENTARIO', pageWidth / 2, y, { align: 'center' });

  y += 6;
  doc.setFontSize(10);
  doc.setTextColor(0, 86, 91);
  doc.text(`EXPEDIENTE OFICIAL NO. ${correlativo}`, pageWidth / 2, y, { align: 'center' });

  // Applicant Metadata Card
  y += 6;
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setFillColor(248, 250, 252); // slate-50
  doc.roundedRect(14, y, pageWidth - 28, 26, 2, 2, 'FD');

  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text('FECHA Y HORA DE EMISIÓN:', 18, y + 6);
  doc.text('SOLICITANTE RESPONSABLE:', 18, y + 13);
  doc.text('REGISTRO DE PERSONAL:', 18, y + 20);

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text(fecha, 68, y + 6);
  doc.text(solicitante.nombreCompleto.toUpperCase(), 68, y + 13);
  doc.text(solicitante.numeroPersonal, 68, y + 20);

  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'normal');
  doc.text('UNIDAD ACADÉMICA / DEPARTAMENTO:', 115, y + 6);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('Facultad de Agronomía (FAUSAC)', 115, y + 13);

  // Separate goods into:
  // 1. Registered to applicant
  // 2. Extra goods for administrative verification
  const bienesACargo = bienes.filter(b => !b.fueraDeCargo);
  const bienesAVerificar = bienes.filter(b => b.fueraDeCargo);

  y += 32;

  // Section 1: Bienes a su cargo
  if (bienesACargo.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(0, 86, 91);
    doc.text('SECCIÓN 1: BIENES REGISTRADOS A SU CARGO (ACTIVOS PATRIMONIALES)', 14, y);

    const cargoTableRows = bienesACargo.map((b, i) => [
      String(i + 1),
      b.inventario,
      b.descripcion || 'Sin descripción',
      `Q${parseFloat(String(b.valor).replace(/[^0-9.]/g, '') || '0').toLocaleString('es-GT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      b.tarjeta || 'N/D',
      b.ubicacion || 'N/D',
      b.renglon || 'N/D',
    ]);

    autoTable(doc, {
      startY: y + 2,
      head: [['No.', 'Inventario', 'Descripción del Bien', 'Valor (Q)', 'Tarjeta', 'Ubicación', 'Renglón']],
      body: cargoTableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [0, 86, 91],
        textColor: [255, 255, 255],
        fontSize: 8,
        fontStyle: 'bold',
        halign: 'left',
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2,
        textColor: [15, 23, 42],
        lineColor: [226, 232, 240],
        lineWidth: 0.1,
      },
      columnStyles: {
        0: { cellWidth: 8, halign: 'center' },
        1: { cellWidth: 26, fontStyle: 'bold' },
        2: { cellWidth: 62 },
        3: { cellWidth: 22, halign: 'right' },
        4: { cellWidth: 22 },
        5: { cellWidth: 32 },
        6: { cellWidth: 16, halign: 'center' },
      },
      margin: { left: 14, right: 14 },
    });

    // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
    y = doc.lastAutoTable.finalY + 8;
  }

  // Section 2: Bienes adicionales para verificación
  if (bienesAVerificar.length > 0) {
    // If y is close to bottom, add page
    if (y > 210) {
      doc.addPage();
      y = 20;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(217, 119, 6); // amber-600
    doc.text('SECCIÓN 2: BIENES ADICIONALES PARA VERIFICACIÓN ADMINISTRATIVA', 14, y);

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('Nota: Bienes no registrados a nombre del solicitante en la base actual pero adjuntados con fines de regularización patrimonial.', 14, y + 4);

    const extraTableRows = bienesAVerificar.map((b, i) => [
      String(i + 1),
      b.inventario,
      b.descripcion || 'Sin descripción en sistema',
      b.valor !== 'N/D' ? `Q${parseFloat(String(b.valor).replace(/[^0-9.]/g, '') || '0').toLocaleString('es-GT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : 'N/D',
      b.tarjeta || 'N/D',
      b.ubicacion || 'N/D',
      b.responsableOriginal || 'No asignado / Desconocido',
    ]);

    autoTable(doc, {
      startY: y + 6,
      head: [['No.', 'Inventario', 'Descripción del Bien', 'Valor (Q)', 'Tarjeta', 'Ubicación', 'Responsable Registrado']],
      body: extraTableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [180, 83, 9], // darker amber
        textColor: [255, 255, 255],
        fontSize: 8,
        fontStyle: 'bold',
        halign: 'left',
      },
      styles: {
        fontSize: 7.5,
        cellPadding: 2,
        textColor: [15, 23, 42],
        lineColor: [226, 232, 240],
        lineWidth: 0.1,
      },
      columnStyles: {
        0: { cellWidth: 8, halign: 'center' },
        1: { cellWidth: 26, fontStyle: 'bold' },
        2: { cellWidth: 58 },
        3: { cellWidth: 20, halign: 'right' },
        4: { cellWidth: 22 },
        5: { cellWidth: 28 },
        6: { cellWidth: 26 },
      },
      margin: { left: 14, right: 14 },
    });

    // @ts-expect-error autoTable adds lastAutoTable to jsPDF instance
    y = doc.lastAutoTable.finalY + 8;
  }

  // Legal and Administrative Disclaimer Box
  if (y > 215) {
    doc.addPage();
    y = 20;
  }

  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, y, pageWidth - 28, 20, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('AVISO LEGAL Y ADMINISTRATIVO INSTITUCIONAL:', 18, y + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.setTextColor(71, 85, 105);
  const legalText = 'La presente solicitud constituye únicamente un expediente digital de revisión y cotejo patrimonial para la Unidad de Inventarios de la Facultad de Agronomía (USAC). No autoriza la disposición final ni la destrucción de los bienes hasta que se cuente con la inspección física, dictamen técnico favorable y las firmas correspondientes de la Comisión de Bajas según la normativa universitaria vigente.';
  doc.text(legalText, 18, y + 9, { maxWidth: pageWidth - 36, lineHeightFactor: 1.25 });

  // Signature lines
  y += 34;
  if (y > 250) {
    doc.addPage();
    y = 30;
  }

  const sigCol1 = 45;
  const sigCol2 = pageWidth - 45;

  doc.setDrawColor(100, 116, 139);
  doc.setLineWidth(0.3);
  doc.line(sigCol1 - 32, y, sigCol1 + 32, y);
  doc.line(sigCol2 - 32, y, sigCol2 + 32, y);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('FIRMA DEL SOLICITANTE', sigCol1, y + 5, { align: 'center' });
  doc.text('VO. BO. UNIDAD DE INVENTARIOS', sigCol2, y + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text(solicitante.nombreCompleto, sigCol1, y + 9, { align: 'center' });
  doc.text(`Reg. Personal: ${solicitante.numeroPersonal}`, sigCol1, y + 12.5, { align: 'center' });
  doc.text('Facultad de Agronomía - USAC', sigCol2, y + 9, { align: 'center' });

  // Footer page indicator
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Expediente ${correlativo} · Facultad de Agronomía USAC · Página ${i} de ${totalPages}`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 7,
      { align: 'center' }
    );
  }

  const fileName = `Solicitud_Bajas_${correlativo}.pdf`;
  const blob = doc.output('blob');
  const base64 = doc.output('datauristring').split(',')[1] || '';

  return { doc, fileName, blob, base64 };
}
