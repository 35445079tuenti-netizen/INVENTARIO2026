import React from 'react';
import { FileText, RefreshCw, CheckCircle2, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  activeTab: 'chat' | 'goods' | 'review';
  setActiveTab: (tab: 'chat' | 'goods' | 'review') => void;
  onReset: () => void;
  solicitanteName?: string;
  selectedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onReset,
  solicitanteName,
  selectedCount,
}) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Top institutional sub-bar */}
      <div className="bg-[#004145] text-teal-50 px-4 py-1 text-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-semibold tracking-wide">UNIVERSIDAD DE SAN CARLOS DE GUATEMALA</span>
            <span className="text-teal-300">·</span>
            <span className="text-teal-100 hidden sm:inline">FACULTAD DE AGRONOMÍA</span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-teal-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Portal Oficial de Gestión de Inventario</span>
            </span>
            {solicitanteName && (
              <>
                <span className="text-teal-400">|</span>
                <span className="text-amber-200 font-medium truncate max-w-[200px]">
                  {solicitanteName}
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Navigation Header - Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-6">
        {/* Zone 1: Brand title with USAC badge (no circular logo image) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="bg-[#00565b] text-white font-black text-sm px-2.5 py-1.5 rounded-lg tracking-wider shadow-xs">
            USAC
          </div>
          <div>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('chat');
              }}
              className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap block hover:text-[#00565b] transition-colors"
            >
              Asistente de Bajas de Inventario
            </a>
            <span className="text-xs text-slate-500 font-medium block">
              Unidad de Inventario y Bienes Muebles · FAUSAC
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation links strictly for applicant users */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveTab('chat')}
            className={`whitespace-nowrap transition-colors pb-0.5 border-b-2 cursor-pointer ${
              activeTab === 'chat'
                ? 'border-[#00565b] text-[#00565b] font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Orientación y Chat
          </button>

          <button
            onClick={() => setActiveTab('goods')}
            className={`whitespace-nowrap transition-colors pb-0.5 border-b-2 cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'goods'
                ? 'border-[#00565b] text-[#00565b] font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <span>Selección de Bienes</span>
            {selectedCount > 0 && (
              <span className="text-xs bg-teal-100 text-[#00565b] font-semibold px-1.5 py-0.2 rounded-md">
                {selectedCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('review')}
            className={`whitespace-nowrap transition-colors pb-0.5 border-b-2 cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'review'
                ? 'border-[#00565b] text-[#00565b] font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <span>Expediente y PDF</span>
            {selectedCount > 0 && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onReset}
            title="Reiniciar sesión y limpiar formulario"
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 hover:text-slate-900 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Nueva Sesión</span>
          </button>

          <button
            onClick={() => setActiveTab('review')}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-[#00565b] hover:bg-[#004145] rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-teal-200" />
            <span>Generar PDF</span>
          </button>
        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="md:hidden border-t border-slate-200 bg-slate-50 px-3 py-1.5 flex items-center gap-2 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-3 py-1 rounded-md whitespace-nowrap ${
            activeTab === 'chat' ? 'bg-[#00565b] text-white' : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          Chat y Guía
        </button>
        <button
          onClick={() => setActiveTab('goods')}
          className={`px-3 py-1 rounded-md whitespace-nowrap flex items-center gap-1 ${
            activeTab === 'goods' ? 'bg-[#00565b] text-white' : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          Bienes ({selectedCount})
        </button>
        <button
          onClick={() => setActiveTab('review')}
          className={`px-3 py-1 rounded-md whitespace-nowrap ${
            activeTab === 'review' ? 'bg-[#00565b] text-white' : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          Expediente y PDF
        </button>
      </div>
    </header>
  );
};
