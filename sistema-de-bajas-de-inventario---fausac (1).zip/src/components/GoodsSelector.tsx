import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  Search,
  PlusCircle,
  FileCheck,
  Building2,
  Trash2,
  Info,
  Layers,
  ArrowRight
} from 'lucide-react';
import { BienItem, SolicitanteInfo } from '../utils/pdfGenerator';
import { consultarInventario } from '../services/inventoryService';

interface GoodsSelectorProps {
  solicitante: SolicitanteInfo | null;
  cargoGoods: BienItem[];
  extraGoods: BienItem[];
  setExtraGoods: React.Dispatch<React.SetStateAction<BienItem[]>>;
  selectedMap: Map<string, BienItem>;
  setSelectedMap: React.Dispatch<React.SetStateAction<Map<string, BienItem>>>;
  onContinueToReview: () => void;
  onGoToChat: () => void;
}

export const GoodsSelector: React.FC<GoodsSelectorProps> = ({
  solicitante,
  cargoGoods,
  extraGoods,
  setExtraGoods,
  selectedMap,
  setSelectedMap,
  onContinueToReview,
  onGoToChat,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [extraInput, setExtraInput] = useState('');
  const [extraSearchMessage, setExtraSearchMessage] = useState<{
    text: string;
    type: 'success' | 'info' | 'error';
  } | null>(null);

  // Toggle single item selection
  const handleToggle = (item: BienItem) => {
    const key = String(item.inventario);
    setSelectedMap((prev) => {
      const next = new Map(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.set(key, item);
      }
      return next;
    });
  };

  // Select all or deselect all cargo goods
  const handleSelectAllCargo = (select: boolean) => {
    setSelectedMap((prev) => {
      const next = new Map(prev);
      cargoGoods.forEach((b) => {
        const key = String(b.inventario);
        if (select) {
          next.set(key, b);
        } else {
          next.delete(key);
        }
      });
      return next;
    });
  };

  // Search and add extra inventory item
  const handleAddExtra = () => {
    const inv = extraInput.trim();
    if (!inv) return;

    // Check if already in cargo or extra
    const allKnown = [...cargoGoods, ...extraGoods];
    if (allKnown.some((b) => String(b.inventario).toLowerCase() === inv.toLowerCase())) {
      setExtraSearchMessage({
        text: `El número de inventario ${inv} ya figura en la lista de evaluación.`,
        type: 'info',
      });
      return;
    }

    const res = consultarInventario(inv);
    const bien = res.bien;

    setExtraGoods((prev) => [...prev, bien]);
    // Automatically select it
    setSelectedMap((prev) => {
      const next = new Map(prev);
      next.set(String(bien.inventario), bien);
      return next;
    });

    setExtraInput('');
    if (res.encontrado) {
      setExtraSearchMessage({
        text: `Bien localizado: "${bien.descripcion}". Asignado originalmente a ${bien.responsableOriginal || 'otra dependencia'}. Se ha agregado a la Sección 2 para verificación administrativa.`,
        type: 'success',
      });
    } else {
      setExtraSearchMessage({
        text: `El inventario "${inv}" no se localizó en la base digital, pero fue agregado a la Sección 2 como pendiente de inspección física.`,
        type: 'info',
      });
    }

    setTimeout(() => {
      setExtraSearchMessage(null);
    }, 8000);
  };

  const handleRemoveExtra = (inv: string) => {
    setExtraGoods((prev) => prev.filter((b) => String(b.inventario) !== inv));
    setSelectedMap((prev) => {
      const next = new Map(prev);
      next.delete(inv);
      return next;
    });
  };

  // Filter cargo goods
  const filteredCargo = cargoGoods.filter((b) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      b.inventario.toLowerCase().includes(term) ||
      b.descripcion.toLowerCase().includes(term) ||
      (b.tarjeta && b.tarjeta.toLowerCase().includes(term)) ||
      (b.ubicacion && b.ubicacion.toLowerCase().includes(term))
    );
  });

  // Calculate totals
  const selectedItems = Array.from(selectedMap.values());
  const totalValue = selectedItems.reduce((acc, item) => {
    const num = parseFloat(String(item.valor).replace(/[^0-9.]/g, '') || '0');
    return acc + (isNaN(num) ? 0 : num);
  }, 0);

  const cargoSelectedCount = selectedItems.filter((b) => !b.fueraDeCargo).length;
  const extraSelectedCount = selectedItems.filter((b) => b.fueraDeCargo).length;

  if (!solicitante) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-8 text-center max-w-xl mx-auto shadow-xs">
        <div className="w-12 h-12 rounded-full bg-teal-50 text-[#00565b] flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 mb-2">
          Identificación de Solicitante Requerida
        </h3>
        <p className="text-sm text-slate-600 mb-6 leading-relaxed">
          Para acceder a los activos patrimoniales y tarjetas de responsabilidad de la Facultad de Agronomía, primero debe autenticar su Registro de Personal en el Asistente Virtual.
        </p>
        <button
          onClick={onGoToChat}
          className="px-5 py-2.5 bg-[#00565b] hover:bg-[#004145] text-white text-sm font-semibold rounded-lg inline-flex items-center gap-2 cursor-pointer transition-colors"
        >
          <span>Ir a Identificación en el Asistente</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Solicitante Titular
              </span>
              <span className="text-xs bg-teal-100 text-[#00565b] font-bold px-2 py-0.5 rounded">
                RegPer: {solicitante.numeroPersonal}
              </span>
            </div>
            <h2 className="text-lg font-bold text-slate-900 mt-0.5">
              {solicitante.nombreCompleto}
            </h2>
            <p className="text-xs text-slate-500">
              Facultad de Agronomía · Tarjeta de Bienes Muebles Activa
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-50 px-4 py-2.5 rounded-lg border border-slate-200 self-start sm:self-center">
            <div className="text-right">
              <div className="text-xs text-slate-500 font-medium">Bienes marcados</div>
              <div className="text-base font-bold text-slate-900 tabular-nums">
                {selectedMap.size} de {cargoGoods.length + extraGoods.length}
              </div>
            </div>
            <div className="h-8 w-px bg-slate-200 mx-1"></div>
            <div className="text-right">
              <div className="text-xs text-slate-500 font-medium">Valor patrimonial</div>
              <div className="text-base font-bold text-[#00565b] tabular-nums">
                Q
                {totalValue.toLocaleString('es-GT', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Selection breakdown badges */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-600">Composición del trámite:</span>
            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 rounded border border-emerald-200 font-medium">
              {cargoSelectedCount} a su cargo
            </span>
            {extraSelectedCount > 0 && (
              <span className="px-2 py-0.5 bg-amber-50 text-amber-800 rounded border border-amber-200 font-medium">
                {extraSelectedCount} para verificación
              </span>
            )}
          </div>

          <button
            onClick={onContinueToReview}
            disabled={selectedMap.size === 0}
            className="px-4 py-2 bg-[#00565b] hover:bg-[#004145] disabled:opacity-40 text-white font-semibold rounded-lg flex items-center gap-2 transition-colors cursor-pointer text-xs"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Revisar Expediente Oficial ({selectedMap.size})</span>
          </button>
        </div>
      </div>

      {/* Section 1: Bienes a su cargo */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00565b]"></span>
              <h3 className="text-base font-bold text-slate-900">
                1. Bienes Registrados a su Cargo
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Activos patrimoniales asignados formalmente en su tarjeta de responsabilidad
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar por código, nombre..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b] w-48 sm:w-60"
              />
            </div>

            <button
              onClick={() => handleSelectAllCargo(true)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer"
            >
              Marcar todos
            </button>

            <button
              onClick={() => handleSelectAllCargo(false)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer"
            >
              Desmarcar
            </button>
          </div>
        </div>

        {/* Cargo goods list */}
        {filteredCargo.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-sm">
            No se encontraron bienes que coincidan con la búsqueda.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredCargo.map((item) => {
              const isSelected = selectedMap.has(String(item.inventario));
              return (
                <div
                  key={item.inventario}
                  onClick={() => handleToggle(item)}
                  className={`p-4 transition-colors cursor-pointer flex items-start gap-3.5 hover:bg-slate-50/80 ${
                    isSelected ? 'bg-teal-50/40' : ''
                  }`}
                >
                  <div className="pt-0.5 text-[#00565b]">
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-[#00565b]" />
                    ) : (
                      <Square className="w-5 h-5 text-slate-300 hover:text-slate-400" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <span className="font-semibold text-slate-900 text-sm">
                        {item.descripcion}
                      </span>
                      <span className="text-sm font-bold text-slate-900 tabular-nums shrink-0">
                        Q
                        {parseFloat(
                          String(item.valor).replace(/[^0-9.]/g, '') || '0'
                        ).toLocaleString('es-GT', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </span>
                    </div>

                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                      <span>
                        <strong className="text-slate-700 font-medium">No. Inventario:</strong>{' '}
                        <span className="font-mono text-slate-800">{item.inventario}</span>
                      </span>
                      <span>
                        <strong className="text-slate-700 font-medium">Tarjeta:</strong>{' '}
                        {item.tarjeta || 'N/D'}
                      </span>
                      <span>
                        <strong className="text-slate-700 font-medium">Ubicación:</strong>{' '}
                        {item.ubicacion || 'N/D'}
                      </span>
                      <span>
                        <strong className="text-slate-700 font-medium">Renglón:</strong>{' '}
                        {item.renglon || 'N/D'}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[11px] font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        Registrado a su cargo
                      </span>
                      {item.estado && (
                        <span className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                          Estado reportado: {item.estado}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Section 2: Bienes adicionales para verificación administrativa */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <h3 className="text-base font-bold text-slate-900">
              2. Bienes Adicionales para Verificación Administrativa
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            ¿Posee en su custodia o laboratorio algún bien mueble que no aparece en su tarjeta oficial? Agréguelo aquí para que la Unidad de Inventario efectúe la regularización correspondiente.
          </p>

          {/* Add item input bar */}
          <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Ingrese número de inventario o placa (ej. 2015-00412)..."
                value={extraInput}
                onChange={(e) => setExtraInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddExtra();
                  }
                }}
                className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
            </div>
            <button
              type="button"
              onClick={handleAddExtra}
              disabled={!extraInput.trim()}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Buscar y Agregar al Trámite</span>
            </button>
          </div>

          {extraSearchMessage && (
            <div
              className={`mt-2.5 p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                extraSearchMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  : 'bg-amber-50 text-amber-900 border border-amber-200'
              }`}
            >
              <Info className="w-4 h-4 shrink-0" />
              <span>{extraSearchMessage.text}</span>
            </div>
          )}
        </div>

        {extraGoods.length === 0 ? (
          <div className="p-6 text-center text-slate-500 text-xs">
            No se han agregado bienes adicionales. Si todos sus bienes están en la Sección 1, puede proceder directamente a la revisión del expediente.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {extraGoods.map((item) => {
              const isSelected = selectedMap.has(String(item.inventario));
              return (
                <div
                  key={item.inventario}
                  className="p-4 flex items-start gap-3.5 bg-amber-50/20 hover:bg-amber-50/40 transition-colors"
                >
                  <div
                    className="pt-0.5 text-amber-600 cursor-pointer"
                    onClick={() => handleToggle(item)}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-amber-600" />
                    ) : (
                      <Square className="w-5 h-5 text-slate-300 hover:text-slate-400" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0" onClick={() => handleToggle(item)}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <span className="font-semibold text-slate-900 text-sm">
                        {item.descripcion}
                      </span>
                      <span className="text-sm font-bold text-slate-900 tabular-nums shrink-0">
                        {item.valor !== 'N/D'
                          ? `Q${parseFloat(
                              String(item.valor).replace(/[^0-9.]/g, '') || '0'
                            ).toLocaleString('es-GT', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}`
                          : 'Valor N/D'}
                      </span>
                    </div>

                    <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                      <span>
                        <strong className="text-slate-700 font-medium">No. Inventario:</strong>{' '}
                        <span className="font-mono text-slate-800">{item.inventario}</span>
                      </span>
                      <span>
                        <strong className="text-slate-700 font-medium">Tarjeta:</strong>{' '}
                        {item.tarjeta || 'N/D'}
                      </span>
                      <span>
                        <strong className="text-slate-700 font-medium">Ubicación:</strong>{' '}
                        {item.ubicacion || 'N/D'}
                      </span>
                      {item.responsableOriginal && (
                        <span>
                          <strong className="text-slate-700 font-medium">Titular en base:</strong>{' '}
                          {item.responsableOriginal}
                        </span>
                      )}
                    </div>

                    <div className="mt-2">
                      <span className="text-[11px] font-medium text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        Adicional · Para Verificación Administrativa
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleRemoveExtra(String(item.inventario))}
                    title="Quitar bien de la lista"
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Action Footer */}
      <div className="bg-slate-100 p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <Layers className="w-4 h-4 text-[#00565b]" />
          <span>
            Total seleccionado para baja:{' '}
            <strong className="text-slate-900">{selectedMap.size} bienes</strong>
          </span>
        </div>

        <button
          onClick={onContinueToReview}
          disabled={selectedMap.size === 0}
          className="px-6 py-2.5 bg-[#00565b] hover:bg-[#004145] disabled:opacity-40 text-white font-semibold rounded-lg text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
        >
          <span>Continuar a Revisión de Expediente</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
