import React, { useState } from 'react';
import { Database, Search, Plus, RotateCcw, UserCheck, Shield } from 'lucide-react';
import {
  getStoredInventory,
  saveInventory,
  resetInventoryToDefault,
  InventarioRow,
} from '../data/inventoryData';
import { SolicitanteInfo, BienItem } from '../utils/pdfGenerator';
import { obtenerBienesActivos } from '../services/inventoryService';

interface InventoryManagerProps {
  onSelectPersona: (solicitante: SolicitanteInfo, goods: BienItem[]) => void;
  onDataChanged: () => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({
  onSelectPersona,
  onDataChanged,
}) => {
  const [data, setData] = useState<InventarioRow[]>(getStoredInventory());
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // New item form state
  const [newItem, setNewItem] = useState<Partial<InventarioRow>>({
    personal: '',
    nombre: '',
    inventario: '',
    descripcion: '',
    valor: '',
    tarjeta: '',
    ubicacion: '',
    estado: 'Regular',
    renglon: '324',
  });

  const handleReset = () => {
    if (confirm('¿Desea restaurar la base de inventario a los valores institucionales predeterminados?')) {
      const def = resetInventoryToDefault();
      setData(def);
      onDataChanged();
    }
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.personal || !newItem.nombre || !newItem.inventario || !newItem.descripcion) {
      alert('Por favor complete los campos obligatorios: Personal, Nombre, Inventario y Descripción.');
      return;
    }

    const primerNombre = newItem.nombre.trim().split(' ')[0].toLowerCase();
    const itemToAdd: InventarioRow = {
      personal: newItem.personal.trim(),
      nombre: newItem.nombre.trim(),
      primerNombre,
      departamento: newItem.departamento || 'Facultad de Agronomía',
      inventario: newItem.inventario.trim(),
      descripcion: newItem.descripcion.trim(),
      valor: newItem.valor || '0.00',
      tarjeta: newItem.tarjeta || 'N/D',
      ubicacion: newItem.ubicacion || 'Facultad de Agronomía',
      estado: newItem.estado || 'Regular',
      renglon: newItem.renglon || '328',
    };

    const updated = [itemToAdd, ...data];
    setData(updated);
    saveInventory(updated);
    onDataChanged();
    setShowAddForm(false);
    setNewItem({
      personal: '',
      nombre: '',
      inventario: '',
      descripcion: '',
      valor: '',
      tarjeta: '',
      ubicacion: '',
      estado: 'Regular',
      renglon: '324',
    });
  };

  const handleLoginAs = (row: InventarioRow) => {
    const sol: SolicitanteInfo = {
      numeroPersonal: row.personal,
      nombreCompleto: row.nombre,
    };
    const res = obtenerBienesActivos(row.personal);
    onSelectPersona(sol, res.bienes || []);
  };

  const filtered = data.filter((row) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      row.nombre.toLowerCase().includes(s) ||
      row.personal.toLowerCase().includes(s) ||
      row.inventario.toLowerCase().includes(s) ||
      row.descripcion.toLowerCase().includes(s) ||
      (row.ubicacion && row.ubicacion.toLowerCase().includes(s))
    );
  });

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#00565b]" />
            <h2 className="text-base font-bold text-slate-900">
              Base de Inventario Activo · FAUSAC
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Registro patrimonial de activos, números de personal y tarjetas de responsabilidad
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-3.5 py-1.5 bg-[#00565b] hover:bg-[#004145] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{showAddForm ? 'Cancelar' : 'Agregar Bien al Sistema'}</span>
          </button>

          <button
            onClick={handleReset}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-200"
            title="Restablecer datos originales"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer</span>
          </button>
        </div>
      </div>

      {/* Add Item Form Modal/Drawer */}
      {showAddForm && (
        <form
          onSubmit={handleAddItem}
          className="bg-teal-50/40 border border-teal-200 rounded-xl p-5 shadow-xs space-y-4"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#00565b] flex items-center gap-1.5">
              <Plus className="w-4 h-4" />
              <span>Registrar Nuevo Activo en la Base de Agronomía</span>
            </h3>
            <span className="text-[11px] text-slate-500">* Campos obligatorios</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">No. Personal *</label>
              <input
                type="text"
                placeholder="ej. 10245"
                value={newItem.personal || ''}
                onChange={(e) => setNewItem({ ...newItem, personal: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Nombre Completo *</label>
              <input
                type="text"
                placeholder="ej. Carlos Mendoza Solórzano"
                value={newItem.nombre || ''}
                onChange={(e) => setNewItem({ ...newItem, nombre: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">No. Inventario / SIIF *</label>
              <input
                type="text"
                placeholder="ej. 2023-00124"
                value={newItem.inventario || ''}
                onChange={(e) => setNewItem({ ...newItem, inventario: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-semibold mb-1">Descripción del Bien *</label>
              <input
                type="text"
                placeholder="ej. Computadora portátil HP EliteBook con cargador"
                value={newItem.descripcion || ''}
                onChange={(e) => setNewItem({ ...newItem, descripcion: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
                required
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Valor en Quetzales (Q)</label>
              <input
                type="text"
                placeholder="ej. 6500.00"
                value={newItem.valor || ''}
                onChange={(e) => setNewItem({ ...newItem, valor: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Tarjeta de Responsabilidad</label>
              <input
                type="text"
                placeholder="ej. TR-2023-019"
                value={newItem.tarjeta || ''}
                onChange={(e) => setNewItem({ ...newItem, tarjeta: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Ubicación Física</label>
              <input
                type="text"
                placeholder="ej. Edificio T-8 Laboratorio de Suelos"
                value={newItem.ubicacion || ''}
                onChange={(e) => setNewItem({ ...newItem, ubicacion: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Renglón Presupuestario</label>
              <input
                type="text"
                placeholder="ej. 322"
                value={newItem.renglon || ''}
                onChange={(e) => setNewItem({ ...newItem, renglon: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 bg-slate-200 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-300 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#00565b] text-white text-xs font-semibold rounded-md hover:bg-[#004145] cursor-pointer shadow-xs"
            >
              Guardar en Base
            </button>
          </div>
        </form>
      )}

      {/* Search and Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por responsable, No. personal o inventario..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#00565b]"
            />
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Mostrando {filtered.length} de {data.length} registros
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">No. Personal</th>
                <th className="py-2.5 px-3">Responsable</th>
                <th className="py-2.5 px-3">No. Inventario</th>
                <th className="py-2.5 px-3">Descripción</th>
                <th className="py-2.5 px-3 text-right">Valor (Q)</th>
                <th className="py-2.5 px-3">Tarjeta</th>
                <th className="py-2.5 px-3">Ubicación</th>
                <th className="py-2.5 px-3 text-center">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((item) => (
                <tr key={item.inventario} className="hover:bg-slate-50/70">
                  <td className="py-2.5 px-3 font-mono font-medium text-slate-700">
                    {item.personal}
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900">{item.nombre}</td>
                  <td className="py-2.5 px-3 font-mono text-[#00565b] font-medium">
                    {item.inventario}
                  </td>
                  <td className="py-2.5 px-3 text-slate-800 max-w-xs truncate" title={item.descripcion}>
                    {item.descripcion}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-900 font-medium">
                    Q
                    {parseFloat(
                      String(item.valor).replace(/[^0-9.]/g, '') || '0'
                    ).toLocaleString('es-GT', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{item.tarjeta || 'N/D'}</td>
                  <td className="py-2.5 px-3 text-slate-600 truncate max-w-[140px]">
                    {item.ubicacion || 'N/D'}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => handleLoginAs(item)}
                      title="Probar solicitud como este responsable"
                      className="px-2 py-1 bg-teal-50 hover:bg-teal-100 text-[#00565b] rounded text-[11px] font-semibold transition-colors cursor-pointer inline-flex items-center gap-1 border border-teal-200"
                    >
                      <UserCheck className="w-3 h-3" />
                      <span>Activar</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
