import React, { useState } from 'react';
import {
  FileText,
  Download,
  ArrowLeft,
  Building2,
  Calendar,
  AlertTriangle,
  Loader2,
  CheckCircle2,
  Printer,
  Eye,
  FileCheck2
} from 'lucide-react';
import { BienItem, SolicitanteInfo, generateSolicitudPDFBlob } from '../utils/pdfGenerator';
import { getNextCorrelativo } from '../data/inventoryData';

interface ReviewPanelProps {
  solicitante: SolicitanteInfo | null;
  selectedMap: Map<string, BienItem>;
  onBackToGoods: () => void;
  onReset: () => void;
}

export const ReviewPanel: React.FC<ReviewPanelProps> = ({
  solicitante,
  selectedMap,
  onBackToGoods,
  onReset,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [correlativo] = useState<string>(() => getNextCorrelativo());
  const [generatedPdf, setGeneratedPdf] = useState<{
    blob: Blob;
    fileName: string;
    url: string;
    correlativo: string;
  } | null>(null);

  if (!solicitante || selectedMap.size === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-8 text-center max-w-lg mx-auto shadow-xs">
        <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">
          No hay bienes seleccionados para la solicitud
        </h3>
        <p className="text-xs text-slate-500 mt-1 mb-5">
          Para estructurar el expediente oficial de baja, debe marcar al menos un bien mueble.
        </p>
        <button
          onClick={onBackToGoods}
          className="px-4 py-2 bg-[#00565b] text-white text-xs font-semibold rounded-lg hover:bg-[#004145] transition-colors cursor-pointer"
        >
          Ir a Selección de Bienes
        </button>
      </div>
    );
  }

  const selectedList = Array.from(selectedMap.values());
  const bienesACargo = selectedList.filter((b) => !b.fueraDeCargo);
  const bienesAVerificar = selectedList.filter((b) => b.fueraDeCargo);

  const totalValue = selectedList.reduce((acc, item) => {
    const num = parseFloat(String(item.valor).replace(/[^0-9.]/g, '') || '0');
    return acc + (isNaN(num) ? 0 : num);
  }, 0);

  const handleGenerateAndDownload = async () => {
    setIsGenerating(true);
    try {
      const { fileName, blob } = generateSolicitudPDFBlob(
        solicitante,
        selectedList,
        correlativo
      );

      const url = URL.createObjectURL(blob);
      setGeneratedPdf({ blob, fileName, url, correlativo });

      // Automatically trigger download
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      console.error('Error generating PDF', e);
      alert('Ocurrió un error al generar el archivo PDF.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    if (generatedPdf?.url) {
      const win = window.open(generatedPdf.url, '_blank');
      win?.focus();
    }
  };

  return (
    <div className="space-y-6">
      {/* If PDF was generated, show success card */}
      {generatedPdf && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-emerald-950">
                  ¡Expediente Oficial Generado Exitosamente!
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Se ha generado y descargado el documento oficial con número correlativo{' '}
                  <strong className="font-mono text-emerald-900">{generatedPdf.correlativo}</strong>.
                </p>
                <p className="text-xs text-emerald-700 mt-1">
                  Por favor imprima el documento, firme en la casilla correspondiente y entréguelo a la Unidad de Inventarios de Agronomía para la programación de la inspección física.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
              <a
                href={generatedPdf.url}
                download={generatedPdf.fileName}
                className="px-3.5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Descargar de nuevo</span>
              </a>

              <button
                onClick={handlePrint}
                className="px-3.5 py-2 bg-white border border-emerald-300 text-emerald-900 hover:bg-emerald-100/50 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Imprimir</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Review Paper Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Institutional Formal Header */}
        <div className="p-6 bg-slate-50/70 border-b border-slate-200 text-center relative">
          <div className="text-[11px] font-bold tracking-widest text-[#00565b] uppercase">
            Universidad de San Carlos de Guatemala
          </div>
          <div className="text-xs font-semibold text-slate-700 mt-0.5">
            Facultad de Agronomía · Unidad de Inventario
          </div>
          <h2 className="text-lg font-extrabold text-slate-900 mt-2">
            SOLICITUD DE PROCESO DE BAJAS DE INVENTARIO
          </h2>
          <div className="inline-block mt-1 px-3 py-0.5 bg-teal-50 border border-teal-200 rounded text-xs font-bold text-[#00565b]">
            Expediente No. {correlativo}
          </div>
        </div>

        {/* Applicant Metadata Block */}
        <div className="p-5 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
          <div>
            <span className="text-slate-500 block font-medium">Docente / Responsable:</span>
            <strong className="text-sm text-slate-900 block font-bold mt-0.5">
              {solicitante.nombreCompleto}
            </strong>
          </div>

          <div>
            <span className="text-slate-500 block font-medium">Registro de Personal:</span>
            <strong className="text-sm font-mono text-slate-900 block font-bold mt-0.5">
              {solicitante.numeroPersonal}
            </strong>
          </div>

          <div>
            <span className="text-slate-500 block font-medium">Fecha y Hora de Emisión:</span>
            <span className="text-sm text-slate-700 block font-medium mt-0.5 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              {new Date().toLocaleDateString('es-GT', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
              })}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block font-medium">Dependencia:</span>
            <span className="text-slate-800 block font-medium mt-0.5 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              Facultad de Agronomía (FAUSAC)
            </span>
          </div>

          <div>
            <span className="text-slate-500 block font-medium">Total de Bienes a Evaluar:</span>
            <span className="text-slate-800 block font-bold mt-0.5">
              {selectedList.length} activos ({bienesACargo.length} a su cargo +{' '}
              {bienesAVerificar.length} por verificar)
            </span>
          </div>

          <div>
            <span className="text-slate-500 block font-medium">Monto Patrimonial Declarado:</span>
            <span className="text-sm font-bold text-[#00565b] block font-mono mt-0.5">
              Q
              {totalValue.toLocaleString('es-GT', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </span>
          </div>
        </div>

        {/* Section 1: Bienes a su cargo */}
        {bienesACargo.length > 0 && (
          <div className="p-5 border-b border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-[#00565b] uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00565b]"></span>
                Sección 1: Bienes Registrados a su Cargo ({bienesACargo.length})
              </h4>
              <span className="text-[11px] text-slate-500">Cotejados en tarjeta oficial</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded-lg">
                <thead className="bg-slate-100/80 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3 w-10 text-center">No.</th>
                    <th className="py-2 px-3 w-28">Inventario</th>
                    <th className="py-2 px-3">Descripción Oficial</th>
                    <th className="py-2 px-3 w-24 text-right">Valor (Q)</th>
                    <th className="py-2 px-3 w-28">Tarjeta</th>
                    <th className="py-2 px-3 w-36">Ubicación</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {bienesACargo.map((b, idx) => (
                    <tr key={b.inventario} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 text-center text-slate-400 font-medium">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-800">
                        {b.inventario}
                      </td>
                      <td className="py-2.5 px-3 text-slate-900">{b.descripcion}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-900">
                        Q
                        {parseFloat(
                          String(b.valor).replace(/[^0-9.]/g, '') || '0'
                        ).toLocaleString('es-GT', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{b.tarjeta || 'N/D'}</td>
                      <td className="py-2.5 px-3 text-slate-600">{b.ubicacion || 'N/D'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Section 2: Bienes adicionales para verificación */}
        {bienesAVerificar.length > 0 && (
          <div className="p-5 border-b border-slate-200 bg-amber-50/20">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-amber-700 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                Sección 2: Bienes Adicionales para Verificación Administrativa ({bienesAVerificar.length})
              </h4>
              <span className="text-[11px] text-amber-800 font-medium">
                Pendientes de regularización de tarjeta
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-amber-200/80 rounded-lg bg-white">
                <thead className="bg-amber-100/60 text-amber-900 font-semibold border-b border-amber-200">
                  <tr>
                    <th className="py-2 px-3 w-10 text-center">No.</th>
                    <th className="py-2 px-3 w-28">Inventario</th>
                    <th className="py-2 px-3">Descripción</th>
                    <th className="py-2 px-3 w-24 text-right">Valor (Q)</th>
                    <th className="py-2 px-3 w-28">Tarjeta</th>
                    <th className="py-2 px-3 w-40">Titular en Base General</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-amber-100/60">
                  {bienesAVerificar.map((b, idx) => (
                    <tr key={b.inventario} className="hover:bg-amber-50/40">
                      <td className="py-2.5 px-3 text-center text-amber-700 font-medium">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                        {b.inventario}
                      </td>
                      <td className="py-2.5 px-3 text-slate-900">{b.descripcion}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-900">
                        {b.valor !== 'N/D'
                          ? `Q${parseFloat(
                              String(b.valor).replace(/[^0-9.]/g, '') || '0'
                            ).toLocaleString('es-GT', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}`
                          : 'N/D'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{b.tarjeta || 'N/D'}</td>
                      <td className="py-2.5 px-3 text-amber-900 font-medium">
                        {b.responsableOriginal || 'Sin titular directo / Desconocido'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Legal Disclaimer Box */}
        <div className="p-5 bg-slate-50/80 border-b border-slate-200">
          <div className="p-3.5 bg-white border border-slate-200 rounded-lg text-xs flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-slate-600 leading-relaxed text-[11px]">
              <strong className="text-slate-900 block mb-0.5">
                Aviso Legal y Administrativo Institucional:
              </strong>
              La presente solicitud constituye únicamente un expediente digital de revisión para la Unidad de Inventarios de la Facultad de Agronomía (USAC). No autoriza la disposición final, destrucción ni enajenación de los bienes hasta contar con el dictamen físico ocular, acta suscrita y firmas de la Comisión de Bajas según las normas patrimoniales universitarias.
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-5 bg-white flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={onBackToGoods}
            className="w-full sm:w-auto px-4 py-2.5 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Modificar Selección de Bienes</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleGenerateAndDownload}
              disabled={isGenerating}
              className="w-full sm:w-auto px-6 py-2.5 bg-[#00565b] hover:bg-[#004145] text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-teal-200" />
                  <span>Procesando PDF Oficial...</span>
                </>
              ) : (
                <>
                  <FileCheck2 className="w-4 h-4 text-teal-200" />
                  <span>Generar y Descargar PDF Oficial</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
