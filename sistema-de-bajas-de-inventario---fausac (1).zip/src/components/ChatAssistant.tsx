import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, ArrowRight, UserCheck, Check, AlertCircle } from 'lucide-react';
import { SolicitanteInfo, BienItem } from '../utils/pdfGenerator';
import {
  buscarSolicitante,
  obtenerBienesActivos,
  responderChat,
} from '../services/inventoryService';

export interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  isVerificationSuccess?: boolean;
}

interface ChatAssistantProps {
  solicitante: SolicitanteInfo | null;
  setSolicitante: (s: SolicitanteInfo | null) => void;
  onGoodsLoaded: (goods: BienItem[]) => void;
  onGoToGoods: () => void;
}

export const ChatAssistant: React.FC<ChatAssistantProps> = ({
  solicitante,
  setSolicitante,
  onGoodsLoaded,
  onGoToGoods,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'bot',
      text: '¡Bienvenido(a)! Soy el Asistente Virtual Oficial de Inventarios de la Facultad de Agronomía (USAC).\n\nEstoy aquí para orientarle en consultas sobre su patrimonio asignado y guiarle paso a paso en la formalización de su solicitud de baja de bienes muebles.',
      timestamp: 'Ahora',
    },
    {
      id: 'm2',
      sender: 'bot',
      text: 'Puede consultarme cualquier inquietud sobre normativas y requisitos, o escribir «Quiero dar de baja mis bienes» para iniciar el trámite formal.',
      timestamp: 'Ahora',
    },
  ]);

  const [inputVal, setInputVal] = useState('');
  const [step, setStep] = useState<'chat' | 'numero' | 'nombre' | 'seleccion'>(
    solicitante ? 'seleccion' : 'chat'
  );
  const [tempNumber, setTempNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const addMessage = (sender: 'bot' | 'user', text: string, isVerificationSuccess = false) => {
    const newMsg: ChatMessage = {
      id: Math.random().toString(36).substring(2, 9),
      sender,
      text,
      timestamp: new Date().toLocaleTimeString('es-GT', { hour: '2-digit', minute: '2-digit' }),
      isVerificationSuccess,
    };
    setMessages((prev) => [...prev, newMsg]);
  };

  const handleSend = async (customText?: string) => {
    const text = (customText ?? inputVal).trim();
    if (!text || isProcessing) return;

    setInputVal('');
    addMessage('user', text);
    setIsProcessing(true);

    try {
      // Step: expecting personal registration number
      if (step === 'numero') {
        setTempNumber(text);
        setStep('nombre');
        addMessage(
          'bot',
          `Número de personal registrado: ${text}.\n\nAhora, por favor indique únicamente su PRIMER NOMBRE para cotejarlo con el registro oficial de la Facultad:`
        );
        setIsProcessing(false);
        return;
      }

      // Step: expecting first name to match
      if (step === 'nombre') {
        const check = buscarSolicitante(tempNumber, text);
        if (!check.ok) {
          setStep('numero');
          addMessage(
            'bot',
            `${check.mensaje || 'No se pudieron cotejar los datos.'}\n\nPor favor intente nuevamente ingresando su Número de Personal:`
          );
          setIsProcessing(false);
          return;
        }

        const newSol: SolicitanteInfo = {
          numeroPersonal: check.numeroPersonal!,
          nombreCompleto: check.nombreCompleto!,
        };
        setSolicitante(newSol);

        const goodsRes = obtenerBienesActivos(check.numeroPersonal!);
        const goods = goodsRes.bienes || [];
        onGoodsLoaded(goods);

        setStep('seleccion');
        addMessage(
          'bot',
          `¡Excelente, ${check.nombreCompleto}! Hemos localizado exitosamente su expediente en la Facultad de Agronomía.\n\nSe han detectado ${goods.length} bienes activos bajo su custodia. Puede pasar a la sección de Selección de Bienes para marcarlos e iniciar el documento de baja.`,
          true
        );
        setIsProcessing(false);
        return;
      }

      // Step: general chat or intent to initiate baja
      const norm = text.toLowerCase();
      if (
        /dar de baja|baja de|solicitud de baja|iniciar|tramitar|dar baja|descargo/.test(norm) &&
        !solicitante
      ) {
        setStep('numero');
        addMessage(
          'bot',
          'Con mucho gusto. Para iniciar su solicitud formal y cargar su tarjeta de responsabilidad, por favor ingrese su Número de Registro de Personal:'
        );
      } else {
        const resp = await responderChat(text, solicitante);
        addMessage('bot', resp);
      }
    } catch {
      addMessage(
        'bot',
        'Ocurrió un inconveniente al procesar su solicitud. Por favor verifique la información e intente de nuevo.'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQuickPersona = (numero: string, primerNombre: string, nombreCompleto: string) => {
    setTempNumber(numero);
    const check = buscarSolicitante(numero, primerNombre);
    if (check.ok) {
      addMessage('user', `Identificación: Registro ${numero} (${primerNombre})`);
      const newSol: SolicitanteInfo = {
        numeroPersonal: check.numeroPersonal!,
        nombreCompleto: check.nombreCompleto!,
      };
      setSolicitante(newSol);

      const goodsRes = obtenerBienesActivos(check.numeroPersonal!);
      const goods = goodsRes.bienes || [];
      onGoodsLoaded(goods);

      setStep('seleccion');
      addMessage(
        'bot',
        `Expediente verificado con éxito para ${nombreCompleto}.\n\nSe cargaron ${goods.length} bienes registrados a su nombre. Ya puede continuar a la selección de bienes.`,
        true
      );
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Assistant Header status bar */}
      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-teal-100 border border-teal-200 text-[#00565b] flex items-center justify-center font-bold text-xs">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 leading-tight">
              Módulo de Orientación y Consulta Digital
            </h3>
            <p className="text-xs text-slate-500">
              Facultad de Agronomía · Universidad de San Carlos
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {solicitante ? (
            <div className="flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span className="font-semibold">Verificado: {solicitante.numeroPersonal}</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>En línea</span>
            </div>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/50 min-h-[340px] max-h-[520px]">
        {messages.map((m) => {
          const isBot = m.sender === 'bot';
          return (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-7 h-7 rounded-full bg-[#00565b] text-white flex items-center justify-center text-xs shrink-0 mt-0.5 shadow-xs">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-xs ${
                  isBot
                    ? m.isVerificationSuccess
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-950 rounded-tl-xs'
                      : 'bg-white border border-slate-200 text-slate-900 rounded-tl-xs'
                    : 'bg-[#00565b] text-white rounded-tr-xs font-medium'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>

                {m.isVerificationSuccess && (
                  <div className="mt-3 pt-3 border-t border-emerald-200/80 flex items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-emerald-800 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      Expediente cargado
                    </span>
                    <button
                      onClick={onGoToGoods}
                      className="px-3 py-1 bg-[#00565b] hover:bg-[#004145] text-white rounded-md text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>Ir a Selección de Bienes</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div
                  className={`text-[10px] mt-1.5 text-right ${
                    isBot ? 'text-slate-400' : 'text-teal-100'
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>

              {!isBot && (
                <div className="w-7 h-7 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions & Demo Personas */}
      <div className="px-4 py-2 bg-slate-100/70 border-t border-slate-200 flex flex-wrap items-center gap-1.5 text-xs">
        <span className="text-slate-500 font-semibold text-[11px] mr-1">Consultas rápidas:</span>

        <button
          type="button"
          onClick={() => handleSend('Quiero iniciar el proceso de baja de mis bienes')}
          className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-md transition-colors cursor-pointer"
        >
          Iniciar trámite de baja
        </button>

        <button
          type="button"
          onClick={() => handleSend('¿Cuáles son los requisitos y el procedimiento oficial de bajas?')}
          className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-md transition-colors cursor-pointer"
        >
          Requisitos y procedimiento
        </button>

        <button
          type="button"
          onClick={() => handleSend('¿Qué hago si tengo un bien que no aparece a mi nombre?')}
          className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-md transition-colors cursor-pointer"
        >
          Bienes fuera de mi cargo
        </button>

        {/* Demo profiles picker for instant testing without typing */}
        {!solicitante && (
          <div className="w-full mt-1.5 pt-1.5 border-t border-slate-200 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-amber-600" />
              Probar directamente con usuario de prueba:
            </span>
            <button
              type="button"
              onClick={() => handleQuickPersona('20140273', 'Victor', 'Víctor Manuel Morales Gómez')}
              className="text-[11px] px-2 py-0.5 bg-teal-100 border border-teal-300 text-[#00565b] font-semibold rounded hover:bg-teal-200 cursor-pointer shadow-xs"
            >
              Víctor (#20140273)
            </button>
            <button
              type="button"
              onClick={() => handleQuickPersona('10245', 'Carlos', 'Carlos Mendoza Solórzano')}
              className="text-[11px] px-2 py-0.5 bg-teal-50 border border-teal-200 text-[#00565b] font-medium rounded hover:bg-teal-100 cursor-pointer"
            >
              Carlos Mendoza (#10245)
            </button>
            <button
              type="button"
              onClick={() => handleQuickPersona('10382', 'María', 'María Morales Estrada')}
              className="text-[11px] px-2 py-0.5 bg-teal-50 border border-teal-200 text-[#00565b] font-medium rounded hover:bg-teal-100 cursor-pointer"
            >
              María Morales (#10382)
            </button>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="p-3.5 bg-white border-t border-slate-200 flex items-center gap-2"
      >
        <div className="relative flex-1">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            disabled={isProcessing}
            placeholder={
              step === 'numero'
                ? 'Ingrese su Número de Registro de Personal (ej. 10245)...'
                : step === 'nombre'
                ? 'Ingrese únicamente su PRIMER NOMBRE para cotejo (ej. Carlos)...'
                : 'Escriba su consulta o solicitud sobre inventario...'
            }
            className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00565b]/20 focus:border-[#00565b] transition-all"
          />
        </div>

        <button
          type="submit"
          disabled={!inputVal.trim() || isProcessing}
          className="px-4 py-2.5 bg-[#00565b] hover:bg-[#004145] disabled:opacity-40 disabled:hover:bg-[#00565b] text-white rounded-lg text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
        >
          <span>Enviar</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
