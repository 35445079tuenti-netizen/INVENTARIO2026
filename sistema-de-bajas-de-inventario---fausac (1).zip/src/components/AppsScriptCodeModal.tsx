import React, { useState } from 'react';
import { Copy, Check, FileCode, Terminal, Download, Sparkles } from 'lucide-react';

export const AppsScriptCodeModal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'index' | 'code' | 'instructions'>('index');
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2500);
  };

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  };

  const MODERN_INDEX_HTML = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Asistente de Bajas de Inventario · Facultad de Agronomía USAC</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --primary: #00565b;
    --primary-dark: #004145;
    --primary-light: #e8f5f5;
    --accent: #d97706;
    --accent-light: #fef3c7;
    --bg: #f8fafc;
    --card: #ffffff;
    --border: #e2e8f0;
    --border-strong: #cbd5e1;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --radius-sm: 8px;
    --radius-md: 12px;
    --radius-lg: 16px;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
    --shadow-md: 0 4px 14px -2px rgba(0,0,0,0.06);
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background-color: var(--bg);
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: var(--text-main);
    line-height: 1.5;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  /* Institutional Subheader Bar */
  .sub-bar {
    background: #003639;
    color: #e6fffa;
    padding: 6px 20px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.5px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  /* Main Header */
  header {
    background: var(--card);
    border-bottom: 1px solid var(--border);
    padding: 14px 24px;
    box-shadow: var(--shadow-sm);
    position: sticky;
    top: 0;
    z-index: 20;
  }

  .header-content {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
  }

  .brand-lockup {
    display: flex;
    align-items: center;
    gap: 14px;
  }

  .logo-crest {
    background: linear-gradient(135deg, #00565b 0%, #003639 100%);
    color: #ffffff;
    font-weight: 800;
    width: 44px;
    height: 44px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    letter-spacing: 1px;
    border: 1px solid rgba(255,255,255,0.2);
    box-shadow: 0 4px 10px rgba(0,86,91,0.25);
    flex-shrink: 0;
  }

  .brand-titles h1 {
    font-size: 17px;
    font-weight: 800;
    color: var(--text-main);
    letter-spacing: -0.3px;
    line-height: 1.2;
  }

  .brand-titles p {
    font-size: 12px;
    color: var(--text-muted);
    font-weight: 500;
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .status-badge {
    font-size: 11.5px;
    background: var(--primary-light);
    color: var(--primary);
    padding: 5px 12px;
    border-radius: 20px;
    font-weight: 700;
    border: 1px solid rgba(0,86,91,0.15);
    white-space: nowrap;
  }

  /* Main Workspace */
  main {
    max-width: 1000px;
    width: 100%;
    margin: 24px auto;
    padding: 0 16px;
    flex: 1;
  }

  .panel-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
    overflow: hidden;
  }

  /* Chat Thread */
  #chat {
    height: 340px;
    overflow-y: auto;
    background: #f8fafc;
    padding: 24px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    border-bottom: 1px solid var(--border);
  }

  #chat::-webkit-scrollbar { width: 6px; }
  #chat::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }

  .msg {
    display: flex;
    gap: 10px;
    align-items: flex-start;
  }

  .msg.user {
    justify-content: flex-end;
  }

  .msg-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 700;
    flex-shrink: 0;
  }

  .bot .msg-avatar {
    background: var(--primary);
    color: #ffffff;
  }

  .user .msg-avatar {
    background: #334155;
    color: #ffffff;
    order: 2;
  }

  .bubble {
    max-width: 80%;
    padding: 13px 17px;
    border-radius: 14px;
    font-size: 13.5px;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-word;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
  }

  .bot .bubble {
    background: #ffffff;
    color: var(--text-main);
    border: 1px solid var(--border);
    border-top-left-radius: 4px;
  }

  .user .bubble {
    background: var(--primary);
    color: #ffffff;
    border-top-right-radius: 4px;
    font-weight: 500;
  }

  /* Suggestions Bar */
  .suggestions-strip {
    padding: 10px 20px;
    background: #f1f5f9;
    border-bottom: 1px solid var(--border);
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    font-size: 12px;
  }

  .chip-btn {
    background: #ffffff;
    border: 1px solid var(--border-strong);
    color: #334155;
    padding: 5px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .chip-btn:hover {
    background: #f8fafc;
    border-color: var(--primary);
    color: var(--primary);
  }

  /* Input Form */
  .input-area {
    padding: 20px 24px;
    background: var(--card);
  }

  .chat-input-row {
    display: flex;
    gap: 10px;
  }

  input[type="text"] {
    width: 100%;
    padding: 12px 16px;
    border: 1.5px solid var(--border-strong);
    border-radius: var(--radius-sm);
    font-size: 14px;
    font-family: inherit;
    outline: none;
    transition: all 0.2s ease;
    background: #ffffff;
  }

  input[type="text"]:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(0, 86, 91, 0.12);
  }

  button {
    padding: 11px 20px;
    border: none;
    border-radius: var(--radius-sm);
    font-size: 13.5px;
    font-weight: 700;
    font-family: inherit;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    white-space: nowrap;
  }

  button.primary {
    background: var(--primary);
    color: #ffffff;
    box-shadow: 0 2px 6px rgba(0, 86, 91, 0.2);
  }

  button.primary:hover {
    background: var(--primary-dark);
    transform: translateY(-1px);
  }

  button.secondary {
    background: #f1f5f9;
    color: var(--text-main);
    border: 1px solid var(--border-strong);
  }

  button.secondary:hover {
    background: #e2e8f0;
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none !important;
  }

  .hidden { display: none !important; }

  /* Goods Selection Section */
  .section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 24px 0 12px 0;
    padding-bottom: 8px;
    border-bottom: 2px solid var(--border);
  }

  .section-title {
    font-size: 15px;
    font-weight: 800;
    color: var(--text-main);
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .section-title.accent {
    color: var(--accent);
  }

  .goods-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 20px;
  }

  .good-card {
    display: flex;
    align-items: flex-start;
    gap: 14px;
    padding: 16px;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: #ffffff;
    transition: all 0.2s ease;
    cursor: pointer;
  }

  .good-card:hover {
    border-color: #94a3b8;
    box-shadow: var(--shadow-sm);
  }

  .good-card.selected {
    background: #f0fdfa;
    border-color: #99f6e4;
  }

  .good-card.extra-item {
    background: #fffdf5;
    border-color: #fde68a;
  }

  .good-card.extra-item.selected {
    background: #fefce8;
    border-color: #fcd34d;
  }

  .good-card input[type="checkbox"] {
    width: 20px;
    height: 20px;
    margin-top: 2px;
    accent-color: var(--primary);
    cursor: pointer;
  }

  .good-info {
    flex: 1;
  }

  .good-header-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 10px;
  }

  .good-info strong {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-main);
  }

  .good-price {
    font-family: 'JetBrains Mono', monospace;
    font-size: 13.5px;
    font-weight: 700;
    color: var(--primary);
    white-space: nowrap;
  }

  .good-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 6px;
  }

  .good-meta span strong {
    color: #475569;
    font-size: 12px;
  }

  .badge-tag {
    display: inline-block;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 6px;
    margin-top: 8px;
  }

  .badge-verified { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
  .badge-pending { background: #fef3c7; color: #b45309; border: 1px solid #fde68a; }

  /* Notice Callout Box */
  .note-box {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    color: #166534;
    padding: 14px 18px;
    border-radius: var(--radius-md);
    font-size: 13px;
    margin: 18px 0;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  /* Footer */
  footer {
    text-align: center;
    font-size: 12px;
    color: var(--text-muted);
    padding: 24px 0 36px 0;
    font-weight: 500;
  }
</style>
</head>
<body>

<div class="sub-bar">
  <span>UNIVERSIDAD DE SAN CARLOS DE GUATEMALA · FACULTAD DE AGRONOMÍA</span>
  <span>PORTAL OFICIAL DE INVENTARIOS</span>
</div>

<header>
  <div class="header-content">
    <div class="brand-lockup">
      <div class="logo-crest">USAC</div>
      <div class="brand-titles">
        <h1>Asistente Virtual de Bajas de Inventario</h1>
        <p>Facultad de Agronomía · Gestión de Activos Patrimoniales</p>
      </div>
    </div>
    <div class="header-actions">
      <span id="status" class="status-badge">Disponible</span>
      <button type="button" id="resetBtn" class="secondary" style="padding: 8px 14px; font-size: 12px;">Nueva Sesión</button>
    </div>
  </div>
</header>

<main>
  <div class="panel-card">
    <!-- Chat Log -->
    <div id="chat"></div>

    <!-- Quick Suggestions Strip -->
    <div class="suggestions-strip">
      <span style="font-weight: 700; color: #475569;">Atajos:</span>
      <button type="button" class="chip-btn" onclick="quickSend('Quiero iniciar el proceso de baja de mis bienes')">Iniciar trámite de baja</button>
      <button type="button" class="chip-btn" onclick="quickSend('¿Cuáles son los requisitos y pasos para el trámite de baja?')">Requisitos y pasos</button>
      <button type="button" class="chip-btn" onclick="quickSend('¿Qué hago si tengo un bien que no aparece a mi nombre?')">Bienes no asignados</button>
    </div>

    <div class="input-area">
      <!-- Chat Form -->
      <form id="chatForm">
        <div class="chat-input-row">
          <input id="message" type="text" autocomplete="off" placeholder="Escriba su consulta o solicitud sobre inventario..." required>
          <button type="submit" id="sendBtn" class="primary">Enviar</button>
        </div>
      </form>

      <!-- Panel de Selección de Bienes -->
      <section id="goodsPanel" class="hidden">
        <div class="section-header">
          <div class="section-title">
            <span>1. Bienes Registrados a su Cargo</span>
          </div>
          <span id="cargoCount" style="font-size: 12px; font-weight: 700; color: var(--primary);"></span>
        </div>
        
        <div id="cargoGoodsList" class="goods-list"></div>

        <!-- Sección de Bienes Adicionales -->
        <div id="extraSection" class="hidden">
          <div class="section-header">
            <div class="section-title accent">
              <span>2. Bienes Adicionales para Verificación Administrativa</span>
            </div>
            <span id="extraCount" style="font-size: 12px; font-weight: 700; color: var(--accent);"></span>
          </div>
          <div id="extraGoodsList" class="goods-list"></div>
        </div>

        <!-- Buscador de inventarios externos -->
        <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: var(--radius-md); padding: 18px; margin-top: 20px;">
          <label for="extraInput" style="display: block; font-size: 13px; font-weight: 700; margin-bottom: 8px;">
            ¿Posee otro bien físico en su área que no aparece en la lista superior?
          </label>
          <div style="display: flex; gap: 10px;">
            <input id="extraInput" type="text" placeholder="Ingrese el número de inventario o correlativo...">
            <button type="button" id="addExtraBtn" class="secondary">Buscar y Agregar</button>
          </div>
          <p style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">
            El sistema buscará los datos en el inventario general y lo anexará en la Sección 2 para cotejo de la comisión.
          </p>
        </div>

        <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
          <button type="button" id="reviewBtn" class="primary" style="padding: 14px 28px; font-size: 14px;">
            Revisar Expediente Oficial
          </button>
        </div>
      </section>

      <!-- Panel de Revisión de Expediente -->
      <section id="reviewPanel" class="hidden">
        <div class="section-header">
          <div class="section-title">
            <span>Resumen del Expediente de Baja</span>
          </div>
        </div>

        <div id="applicantInfo" style="font-size: 13.5px; background: #f8fafc; border: 1px solid var(--border); padding: 14px 18px; border-radius: var(--radius-md); margin-bottom: 16px;"></div>
        
        <div id="summaryList" class="goods-list"></div>

        <div class="note-box" style="background: #fffbeb; border-color: #fde68a; color: #92400e;">
          <div>
            <strong>Aviso Legal Institucional:</strong> Este expediente consolida los bienes solicitados para inspección ocular de la Comisión de Bajas de la Facultad de Agronomía. Genera un número correlativo oficial de solicitud.
          </div>
        </div>

        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px;">
          <button type="button" id="backBtn" class="secondary">Modificar Bienes</button>
          <button type="button" id="pdfBtn" class="primary">Generar y Descargar PDF Oficial</button>
        </div>
      </section>

      <!-- Panel Final de Confirmación -->
      <section id="resultPanel" class="hidden">
        <div class="note-box">
          <div>
            <strong style="font-size: 15px;">¡Solicitud Generada con Éxito!</strong><br>
            El documento PDF oficial se ha descargado a su equipo. Imprímalo y preséntelo debidamente firmado a la Unidad de Inventario de Agronomía.
          </div>
        </div>
        <p id="resultCorrelativo" style="font-weight: 800; font-size: 18px; margin: 20px 0; color: var(--primary); text-align: center; font-family: 'JetBrains Mono', monospace;"></p>
        <div style="display: flex; justify-content: center; gap: 12px;">
          <button type="button" id="downloadAgainBtn" class="primary">Descargar PDF Nuevamente</button>
        </div>
      </section>
    </div>
  </div>
</main>

<footer>
  Universidad de San Carlos de Guatemala · Facultad de Agronomía · Unidad de Inventarios
</footer>

<script>
"use strict";
const $ = id => document.getElementById(id);

const State = {
  step: "chat",
  number: "",
  first: "",
  name: "",
  cargoGoods: [],
  extraGoods: [],
  selectedMap: new Map(),
  pdfBase64: null,
  fileName: ""
};

function say(text, who = "bot") {
  const row = document.createElement("div");
  row.className = "msg " + (who === "user" ? "user" : "bot");

  const avatar = document.createElement("div");
  avatar.className = "msg-avatar";
  avatar.textContent = who === "user" ? "Tú" : "AG";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  row.append(avatar, bubble);
  $("chat").appendChild(row);
  $("chat").scrollTop = $("chat").scrollHeight;
}

function setStatus(t) {
  $("status").textContent = t;
}

function hidePanels() {
  ["goodsPanel", "reviewPanel", "resultPanel"].forEach(id => $(id).classList.add("hidden"));
}

function quickSend(txt) {
  $("message").value = txt;
  submitMessage(txt);
}

function server(fn, ...args) {
  return new Promise((resolve, reject) => {
    if (!window.google || !google.script || !google.script.run) {
      reject(new Error("Ejecute esta aplicación desde Google Apps Script."));
      return;
    }
    google.script.run
      .withSuccessHandler(resolve)
      .withFailureHandler(e => reject(new Error(e.message || "Error en el servidor")))
      [fn](...args);
  });
}

async function submitMessage(text) {
  text = String(text || "").trim();
  if (!text) return;

  say(text, "user");
  $("message").value = "";
  setStatus("Procesando...");

  try {
    if (State.step === "numero") {
      State.number = text;
      State.step = "nombre";
      say("Entendido. Ahora, por favor indique únicamente su PRIMER NOMBRE para cotejarlo con el registro asignado en la Facultad.");
      setStatus("Esperando Primer Nombre");
      return;
    }

    if (State.step === "nombre") {
      State.first = text;
      const check = await server("buscarSolicitante", State.number, State.first);
      
      if (!check.ok) {
        State.step = "numero";
        say(check.mensaje || "No se pudieron cotejar los datos. Intente ingresando nuevamente su número de personal.");
        setStatus("Verificación Fallida");
        return;
      }

      State.number = String(check.numeroPersonal);
      State.name = check.nombreCompleto;

      const res = await server("obtenerBienesActivos", State.number);
      if (!res.ok) throw new Error(res.mensaje || "Error al consultar bienes.");

      State.cargoGoods = res.bienes || [];
      State.extraGoods = [];
      State.selectedMap.clear();

      State.cargoGoods.forEach(b => State.selectedMap.set(String(b.inventario), b));

      State.step = "seleccion";
      say("¡Bienvenido(a), " + State.name + "! He localizado su expediente. A continuación revise los bienes registrados a su cargo y marque los que desea incluir en la solicitud:");
      renderGoods();
      setStatus("Selección de Bienes");
      return;
    }

    const r = await server("responderChat", text, State.number, State.first);
    say(r.respuesta || "No recibí respuesta.");

    const normText = text.toLowerCase();
    if (/dar de baja|baja de|solicitud de baja|iniciar|tramitar/.test(normText) && State.step !== "seleccion") {
      State.step = "numero";
      say("Para iniciar su solicitud formal, por favor proporcione su Número de Registro de Personal:");
      setStatus("Esperando Registro de Personal");
    } else {
      setStatus("Disponible");
    }

  } catch (e) {
    say("Inconveniente: " + e.message);
    setStatus("Error");
  } finally {
    if (State.step !== "seleccion" && State.step !== "revision" && State.step !== "final") {
      setStatus("Disponible");
    }
  }
}

function renderGoods() {
  hidePanels();
  $("goodsPanel").classList.remove("hidden");

  const cargoContainer = $("cargoGoodsList");
  cargoContainer.replaceChildren();

  $("cargoCount").textContent = State.cargoGoods.length + " bienes asignados";

  if (!State.cargoGoods.length) {
    cargoContainer.innerHTML = "<p style='font-size:13px; color:#64748b; padding:12px;'>No se encontraron bienes activos asignados directamente a su registro.</p>";
  } else {
    State.cargoGoods.forEach((b, i) => {
      cargoContainer.appendChild(createGoodCard(b, false, i));
    });
  }

  const extraContainer = $("extraGoodsList");
  extraContainer.replaceChildren();

  if (State.extraGoods.length > 0) {
    $("extraSection").classList.remove("hidden");
    $("extraCount").textContent = State.extraGoods.length + " bienes agregados";
    State.extraGoods.forEach((b, i) => {
      extraContainer.appendChild(createGoodCard(b, true, i));
    });
  } else {
    $("extraSection").classList.add("hidden");
  }
}

function createGoodCard(b, isExtra, index) {
  const inv = String(b.inventario);
  const card = document.createElement("div");
  const isSelected = State.selectedMap.has(inv);
  card.className = "good-card " + (isExtra ? "extra-item " : "") + (isSelected ? "selected" : "");

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = (isExtra ? "ext_" : "car_") + index;
  checkbox.checked = isSelected;

  checkbox.addEventListener("change", e => {
    e.stopPropagation();
    if (checkbox.checked) {
      State.selectedMap.set(inv, b);
      card.classList.add("selected");
    } else {
      State.selectedMap.delete(inv);
      card.classList.remove("selected");
    }
  });

  card.addEventListener("click", () => {
    checkbox.checked = !checkbox.checked;
    checkbox.dispatchEvent(new Event("change"));
  });

  const info = document.createElement("div");
  info.className = "good-info";

  const headerRow = document.createElement("div");
  headerRow.className = "good-header-row";

  const title = document.createElement("strong");
  title.textContent = b.descripcion || "Sin descripción";

  const price = document.createElement("span");
  price.className = "good-price";
  price.textContent = b.valor !== "N/D" ? "Q" + b.valor : "N/D";

  headerRow.append(title, price);

  const meta = document.createElement("div");
  meta.className = "good-meta";
  meta.innerHTML = \`
    <span><strong>No. Inventario:</strong> \${inv}</span>
    <span><strong>Tarjeta:</strong> \${b.tarjeta || 'N/D'}</span>
    <span><strong>Ubicación:</strong> \${b.ubicacion || 'N/D'}</span>
  \`;

  const tag = document.createElement("span");
  if (isExtra) {
    tag.className = "badge-tag badge-pending";
    tag.textContent = "Adicional · Para Verificación Administrativa";
  } else {
    tag.className = "badge-tag badge-verified";
    tag.textContent = "Registrado a su cargo";
  }

  info.append(headerRow, meta, tag);
  card.append(checkbox, info);
  return card;
}

async function addExtra() {
  const input = $("extraInput");
  const invNum = input.value.trim();
  if (!invNum) return;

  const exists = [...State.cargoGoods, ...State.extraGoods].some(b => String(b.inventario) === invNum);
  if (exists) {
    say("El inventario " + invNum + " ya está en la lista.");
    return;
  }

  setStatus("Buscando...");
  try {
    const res = await server("consultarInventario", invNum);
    const bienObtenido = res.bien;

    State.extraGoods.push(bienObtenido);
    State.selectedMap.set(invNum, bienObtenido);
    
    input.value = "";
    renderGoods();

    if (res.encontrado) {
      say(\`Bien localizado: \${bienObtenido.descripcion}. Añadido a la sección de verificación.\`);
    } else {
      say(\`El número \${invNum} no se halló en la base digital, pero se agregó como pendiente de inspección.\`);
    }
    setStatus("Selección de Bienes");
  } catch (e) {
    say("Error: " + e.message);
    setStatus("Error");
  }
}

function review() {
  const selectedList = Array.from(State.selectedMap.values());
  if (!selectedList.length) {
    say("Debe seleccionar al menos un bien para procesar la solicitud.");
    return;
  }

  $("summaryList").replaceChildren();

  selectedList.forEach(b => {
    const item = document.createElement("div");
    item.className = "good-card " + (b.fueraDeCargo ? "extra-item" : "");
    
    const info = document.createElement("div");
    info.className = "good-info";
    
    const title = document.createElement("strong");
    title.textContent = b.descripcion;
    
    const details = document.createElement("div");
    details.className = "good-meta";
    details.innerHTML = \`
      <span><strong>No. Inventario:</strong> \${b.inventario}</span>
      <span><strong>Valor:</strong> Q\${b.valor}</span>
      <span><strong>Tarjeta:</strong> \${b.tarjeta}</span>
    \`;
    
    info.append(title, details);
    item.appendChild(info);
    $("summaryList").appendChild(item);
  });

  $("applicantInfo").innerHTML = \`
    <strong>Solicitante:</strong> \${State.name} &nbsp;|&nbsp; 
    <strong>Registro Personal:</strong> \${State.number} &nbsp;|&nbsp; 
    <strong>Total Bienes a Evaluar:</strong> \${selectedList.length}
  \`;
  
  $("goodsPanel").classList.add("hidden");
  $("reviewPanel").classList.remove("hidden");
  State.step = "revision";
  setStatus("Confirmación de Expediente");
}

async function createPDF() {
  const selectedList = Array.from(State.selectedMap.values());
  if (!selectedList.length) return;

  $("pdfBtn").disabled = true;
  setStatus("Generando PDF...");

  try {
    const res = await server("generarSolicitudPDF", State.number, State.first, selectedList);
    if (!res.ok || !res.base64) throw new Error("No se pudo obtener el PDF.");

    State.pdfBase64 = res.base64;
    State.fileName = res.nombreArchivo;

    downloadPDF(State.pdfBase64, State.fileName);

    $("reviewPanel").classList.add("hidden");
    $("resultPanel").classList.remove("hidden");
    $("resultCorrelativo").textContent = "Correlativo Oficial: " + res.correlativo;

    say(\`Expediente formal \${res.correlativo} generado exitosamente.\`);
    State.step = "final";
    setStatus("PDF Generado");
  } catch (e) {
    say("Error al generar PDF: " + e.message);
    setStatus("Error");
  } finally {
    $("pdfBtn").disabled = false;
  }
}

function downloadPDF(b64, name) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const blob = new Blob([bytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

function resetApp() {
  State.step = "chat";
  State.number = "";
  State.first = "";
  State.name = "";
  State.cargoGoods = [];
  State.extraGoods = [];
  State.selectedMap.clear();
  State.pdfBase64 = null;
  State.fileName = "";

  $("chat").replaceChildren();
  $("message").value = "";
  if ($("extraInput")) $("extraInput").value = "";
  hidePanels();
  setStatus("Disponible");

  say("¡Bienvenido! Soy el Asistente Virtual Oficial de la Facultad de Agronomía (USAC). Le orientaré sobre consultas de inventario y le guiaré en la preparación de su solicitud de baja de bienes.");
  say("Puede consultarme cualquier inquietud o escribir «Quiero dar de baja mis bienes» para iniciar.");
}

$("chatForm").addEventListener("submit", e => {
  e.preventDefault();
  submitMessage($("message").value);
});

$("resetBtn").addEventListener("click", resetApp);
$("addExtraBtn").addEventListener("click", addExtra);
$("reviewBtn").addEventListener("click", review);
$("pdfBtn").addEventListener("click", createPDF);
$("backBtn").addEventListener("click", () => {
  State.step = "seleccion";
  renderGoods();
});
$("downloadAgainBtn").addEventListener("click", () => {
  if (State.pdfBase64) downloadPDF(State.pdfBase64, State.fileName);
});

resetApp();
</script>
</body>
</html>`;

  const CODE_GS = `/************************************************************
 * CHATBOT DE SOLICITUDES DE BAJAS - FACULTAD DE AGRONOMÍA (USAC)
 * Google Apps Script + Google Sheets + Gemini
 ************************************************************/

const CFG = {
  SPREADSHEET_ID: '1tMS9gqHTGWLTwDLiOn0rMTVWTXhwuxcdHfhgfVtlAmk',
  SHEET_NAME: 'Hoja 1',
  TIMEZONE: 'America/Guatemala',
  PREFIJO: 'SPB',
  MODELO_GEMINI: 'gemini-2.5-flash',

  ALIAS: {
    personal: ['RegPer Responsable', 'RegPer', 'Numero de personal', 'No. de personal'],
    nombre: ['Nombre Responsable', 'Nombre completo', 'Nombre del responsable', 'Responsable', 'Nombre'],
    inventario: ['Correlativo', 'No Inventario SIIF', 'No Inventario SICOIN', 'No. Inventario', 'Número de inventario', 'Inventario'],
    descripcion: ['Descripción del bien', 'Descripcion del bien', 'Descripción', 'Descripcion', 'Bien'],
    valor: ['Valor', 'Valor Neto', 'Valor neto', 'Valor del bien'],
    tarjeta: ['Tarjeta', 'Tarjeta No.', 'No. Tarjeta', 'Tarjeta de responsabilidad'],
    ubicacion: ['Ubicación Fisica', 'Ubicacion Fisica', 'Ubicación', 'Ubicacion', 'Lugar'],
    estado: ['Estado', 'Estado del bien', 'Situación', 'Situacion', 'Estado inventario'],
    procedencia: ['Procedencia del bien', 'Procedencia', 'Origen'],
    renglon: ['Renglón', 'Renglon']
  },

  ESTADOS_NO_ACTIVOS: [
    'baja','dado de baja','dados de baja','en proceso',
    'proceso de baja','solicitud de baja','inactivo',
    'retirado','finalizado','baja definitiva'
  ]
};

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Asistente de Proceso de Bajas - Facultad de Agronomía USAC')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function normalizar_(v) {
  return String(v == null ? '' : v).trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\\s+/g, ' ');
}

function hoja_() {
  if (!CFG.SPREADSHEET_ID || CFG.SPREADSHEET_ID.indexOf('PEGAR_') === 0) {
    throw new Error('Configure SPREADSHEET_ID en Code.gs.');
  }
  const ss = SpreadsheetApp.openById(CFG.SPREADSHEET_ID);
  const sh = ss.getSheetByName(CFG.SHEET_NAME);
  if (!sh) throw new Error('No existe la pestaña: ' + CFG.SHEET_NAME);
  return sh;
}

function datos_() {
  const matriz = hoja_().getDataRange().getDisplayValues();
  if (matriz.length < 2) throw new Error('La hoja no contiene datos.');

  const headers = matriz[0].map(v => String(v).trim());
  const hn = headers.map(normalizar_);
  const mapa = {};

  Object.keys(CFG.ALIAS).forEach(campo => {
    const aliasLista = CFG.ALIAS[campo];
    let idx = -1;
    for (let i = 0; i < aliasLista.length; i++) {
      const aliasNorm = normalizar_(aliasLista[i]);
      idx = hn.findIndex(h => h === aliasNorm || h.includes(aliasNorm));
      if (idx >= 0) break;
    }
    mapa[campo] = idx;
  });

  ['personal','nombre','inventario','descripcion'].forEach(c => {
    if (mapa[c] < 0) {
      throw new Error('Falta la columna "' + c + '". Encabezados detectados: ' + headers.join(' | '));
    }
  });

  const filas = matriz.slice(1).map((r, i) => {
    const v = c => mapa[c] >= 0 ? String(r[mapa[c]] || '').trim() : '';
    return {
      fila: i + 2,
      personal: v('personal'),
      nombre: v('nombre'),
      inventario: v('inventario'),
      descripcion: v('descripcion'),
      valor: v('valor'),
      tarjeta: v('tarjeta'),
      ubicacion: v('ubicacion'),
      estado: v('estado'),
      procedencia: v('procedencia'),
      renglon: v('renglon')
    };
  }).filter(x => x.inventario);

  return { headers, mapa, filas };
}

function esActivo_(b, d) {
  if (d.mapa.estado < 0 || !b.estado) return true;
  const e = normalizar_(b.estado);
  return !CFG.ESTADOS_NO_ACTIVOS.some(x => e.includes(normalizar_(x)));
}

function publico_(b) {
  return {
    inventario: b.inventario,
    descripcion: b.descripcion,
    valor: b.valor,
    tarjeta: b.tarjeta,
    ubicacion: b.ubicacion,
    estado: b.estado,
    procedencia: b.procedencia,
    renglon: b.renglon,
    responsableOriginal: b.nombre,
    personalOriginal: b.personal
  };
}

function validarSolicitante_(numero, primerNombre) {
  const n = normalizar_(numero);
  const p = normalizar_(primerNombre);
  if (!n || !p) return { ok: false };

  const d = datos_();
  const filas = d.filas.filter(b => normalizar_(b.personal) === n);
  if (!filas.length) return { ok: false };

  const coincide = filas.some(b => {
    const primerNombreRegistro = normalizar_(b.nombre).split(' ')[0];
    return primerNombreRegistro === p;
  });

  if (!coincide) return { ok: false };

  return {
    ok: true,
    numero: String(numero).trim(),
    nombre: filas[0].nombre
  };
}

function buscarSolicitante(numeroPersonal, primerNombre) {
  const p = validarSolicitante_(numeroPersonal, primerNombre);
  if (!p.ok) {
    return {
      ok: false,
      mensaje: 'No fue posible verificar sus datos. Por favor revise el número de personal y su primer nombre.'
    };
  }
  return {
    ok: true,
    numeroPersonal: p.numero,
    nombreCompleto: p.nombre
  };
}

function obtenerBienesActivos(numeroPersonal) {
  const d = datos_();
  const filas = d.filas.filter(b => normalizar_(b.personal) === normalizar_(numeroPersonal));
  if (!filas.length) return { ok: false, mensaje: 'No se encontraron bienes asignados a su registro de personal.' };

  return {
    ok: true,
    bienes: filas.filter(b => esActivo_(b, d)).map(publico_)
  };
}

function consultarInventario(numeroInventario) {
  const d = datos_();
  const b = d.filas.find(x => normalizar_(x.inventario) === normalizar_(numeroInventario));
  if (!b) {
    return {
      ok: true,
      encontrado: false,
      bien: {
        inventario: numeroInventario,
        descripcion: 'No registrado en la base oficial (requiere verificación)',
        valor: 'N/D',
        tarjeta: 'N/D',
        ubicacion: 'N/D',
        renglon: 'N/D',
        fueraDeCargo: true
      }
    };
  }
  
  const datosPublicos = publico_(b);
  datosPublicos.fueraDeCargo = true;
  return {
    ok: true,
    encontrado: true,
    bien: datosPublicos
  };
}

function responderChat(mensaje, numeroPersonal, primerNombre) {
  mensaje = String(mensaje || '').trim().slice(0, 2000);
  if (!mensaje) return { ok: false, respuesta: 'Escriba su consulta.' };

  const d = datos_();
  let contexto = {
    encabezados: d.headers,
    cantidadRegistros: d.filas.length,
    reglas: [
      'La hoja es una base de inventario de la Facultad de Agronomía USAC.',
      'No confirmar una baja ni modificar estados patrimoniales directamente.',
      'No inventar datos, normas, plazos, correos ni requisitos.',
      'Si falta información, indicar que debe consultarse con la unidad de Inventario.'
    ]
  };

  const identidad = validarSolicitante_(numeroPersonal, primerNombre);

  if (identidad.ok) {
    const propios = d.filas.filter(b => normalizar_(b.personal) === normalizar_(identidad.numero));
    contexto.nombreSolicitante = identidad.nombre;
    contexto.numeroPersonal = identidad.numero;
    contexto.bienesDelSolicitante = propios.map(publico_);
  }

  const key = PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY');
  if (!key) {
    return {
      ok: true,
      respuesta: respuestaBasica_(mensaje, contexto, identidad.ok)
    };
  }

  const instruccion =
    'Eres el asistente virtual de Inventario de la Facultad de Agronomía de la USAC, Guatemala. ' +
    'Habla en español, con amabilidad, profesionalismo y frases breves. ' +
    'Tu objetivo es guiar al usuario para consultas de inventario y preparar su solicitud de baja de bienes. ' +
    'Si el usuario expresa deseo de dar de baja bienes (ej. "quiero dar de baja una silla", "iniciar trámite de baja"), ' +
    'salúdalo cordialmente, indícale que con gusto le apoyas y guíale para que proporcione su número de personal y primer nombre para cotejar su expediente. ' +
    'Usa el CONTEXTO proporcionado y no inventes normativas institucionales. ' +
    'CONTEXTO: ' + JSON.stringify(contexto) +
    '\\nCONSULTA DEL USUARIO: ' + mensaje;

  try {
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' +
      CFG.MODELO_GEMINI + ':generateContent?key=' + encodeURIComponent(key);

    const response = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify({
        contents: [{ parts: [{ text: instruccion }] }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 600 }
      }),
      muteHttpExceptions: true
    });

    const code = response.getResponseCode();
    const body = JSON.parse(response.getContentText());

    if (code < 200 || code >= 300) {
      return { ok: true, respuesta: respuestaBasica_(mensaje, contexto, identidad.ok) };
    }

    const respuesta = (((body.candidates || [])[0] || {}).content || {}).parts || [];
    const texto = respuesta.map(p => p.text || '').join('\\n').trim();

    return {
      ok: true,
      respuesta: texto || respuestaBasica_(mensaje, contexto, identidad.ok)
    };
  } catch (e) {
    return { ok: true, respuesta: respuestaBasica_(mensaje, contexto, identidad.ok) };
  }
}

function respuestaBasica_(mensaje, contexto, verificado) {
  const q = normalizar_(mensaje);

  if (/hola|buenos dias|buenas tardes|buenas noches|saludos/.test(q))
    return '¡Bienvenido! Con gusto le apoyo en su solicitud. ¿Qué gestión o consulta desea realizar hoy?';

  if (/dar de baja|baja de|proceso de baja|solicitud de baja|retirar/.test(q))
    return '¡Bienvenido! Con gusto le apoyo en su solicitud. Para comenzar, por favor proporcione su número de personal.';

  if (/mi inventario|mis bienes|bienes asignados|que bienes/.test(q))
    return verificado
      ? 'Puede revisar la lista de bienes asignados que se muestra en la pantalla.'
      : 'Por motivos de seguridad, para consultar sus bienes favor de indicar su número de personal y primer nombre.';

  return 'Puedo apoyarle a consultar sus bienes registrados y estructurar la solicitud de proceso de bajas para la Facultad de Agronomía.';
}

function reservarCorrelativo() {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const props = PropertiesService.getScriptProperties();
    const anio = Utilities.formatDate(new Date(), CFG.TIMEZONE, 'yyyy');
    const clave = 'CORRELATIVO_' + anio;
    const siguiente = Number(props.getProperty(clave) || 0) + 1;
    props.setProperty(clave, String(siguiente));
    return {
      ok: true,
      correlativo: CFG.PREFIJO + '-' + anio + '-' + String(siguiente).padStart(5, '0')
    };
  } finally {
    lock.releaseLock();
  }
}

function generarSolicitudPDF(numeroPersonal, primerNombre, listaSeleccionados) {
  const persona = validarSolicitante_(numeroPersonal, primerNombre);
  if (!persona.ok) throw new Error('No se pudieron validar los datos del solicitante.');
  if (!Array.isArray(listaSeleccionados) || !listaSeleccionados.length) throw new Error('Seleccione al menos un bien.');

  const d = datos_();

  const bienesACargo = [];
  const bienesAVerificar = [];

  listaSeleccionados.forEach(item => {
    const inv = String(item.inventario).trim();
    const coincidencias = d.filas.filter(b => normalizar_(b.inventario) === normalizar_(inv));
    const asignado = coincidencias.find(b => normalizar_(b.personal) === normalizar_(persona.numero));

    if (asignado) {
      bienesACargo.push({
        ...publico_(asignado),
        estado: esActivo_(asignado, d) ? 'Activo a su cargo' : 'En proceso'
      });
    } else {
      const hallado = coincidencias[0];
      bienesAVerificar.push({
        inventario: inv,
        descripcion: hallado ? hallado.descripcion : (item.descripcion || 'Sin descripción en sistema'),
        valor: hallado ? hallado.valor : 'N/D',
        tarjeta: hallado ? hallado.tarjeta : 'N/D',
        ubicacion: hallado ? hallado.ubicacion : 'N/D',
        renglon: hallado ? hallado.renglon : 'N/D',
        responsableActual: hallado ? hallado.nombre : 'No asignado / Desconocido',
        estado: 'PENDIENTE DE VERIFICACIÓN'
      });
    }
  });

  const corr = reservarCorrelativo().correlativo;
  const fecha = Utilities.formatDate(new Date(), CFG.TIMEZONE, 'dd/MM/yyyy HH:mm');

  const doc = DocumentApp.create('Solicitud_' + corr);
  const body = doc.getBody();

  body.appendParagraph('UNIVERSIDAD DE SAN CARLOS DE GUATEMALA')
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER).setBold(true);
  body.appendParagraph('FACULTAD DE AGRONOMÍA · UNIDAD DE INVENTARIOS')
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER).setBold(true);
  body.appendParagraph('');

  body.appendParagraph('SOLICITUD DE PROCESO DE BAJAS DE INVENTARIO')
    .setHeading(DocumentApp.ParagraphHeading.HEADING1)
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph('No. ' + corr)
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER).setBold(true);
  body.appendParagraph('');

  body.appendParagraph('Fecha de emisión: ' + fecha);
  body.appendParagraph('Nombre del solicitante: ' + persona.nombre);
  body.appendParagraph('Registro de Personal: ' + persona.numero);
  body.appendParagraph('');

  if (bienesACargo.length > 0) {
    body.appendParagraph('SECCIÓN 1: BIENES REGISTRADOS A SU CARGO').setBold(true);
    const t1 = body.appendTable([[
      'No.', 'Inventario', 'Descripción del Bien', 'Valor (Q)', 'Tarjeta', 'Ubicación', 'Renglón'
    ]]);
    bienesACargo.forEach((b, i) => {
      const r = t1.appendTableRow();
      [
        String(i + 1), b.inventario, b.descripcion || '',
        b.valor || '', b.tarjeta || '', b.ubicacion || '', b.renglon || ''
      ].forEach(v => r.appendTableCell(String(v)));
    });
    body.appendParagraph('');
  }

  if (bienesAVerificar.length > 0) {
    body.appendParagraph('-------------------------------------------------------------------------------------------------------------------')
      .setAlignment(DocumentApp.HorizontalAlignment.CENTER);
    body.appendParagraph('SECCIÓN 2: BIENES ADICIONALES PARA VERIFICACIÓN ADMINISTRATIVA').setBold(true);
    body.appendParagraph('Nota: Los siguientes bienes no constan a nombre del solicitante en la base de datos actual pero se incluyen para su revisión y regularización.').setItalic(true);
    
    const t2 = body.appendTable([[
      'No.', 'Inventario', 'Descripción del Bien', 'Valor (Q)', 'Tarjeta', 'Ubicación', 'Responsable Registrado'
    ]]);
    bienesAVerificar.forEach((b, i) => {
      const r = t2.appendTableRow();
      [
        String(i + 1), b.inventario, b.descripcion || '',
        b.valor || '', b.tarjeta || '', b.ubicacion || '', b.responsableActual || ''
      ].forEach(v => r.appendTableCell(String(v)));
    });
    body.appendParagraph('');
  }

  body.appendParagraph(
    'AVISO LEGAL Y ADMINISTRATIVO: La presente solicitud constituye únicamente un expediente digital de revisión ' +
    'para la Unidad de Inventarios de la Facultad de Agronomía. No autoriza la baja definitiva ni altera el estado del patrimonio ' +
    'hasta contar con el dictamen físico y firma de la comisión correspondiente.'
  );
  body.appendParagraph('');
  body.appendParagraph('');
  body.appendParagraph('___________________________________                 ___________________________________');
  body.appendParagraph('         Firma del Solicitante                               Vo. Bo. Inventario - Agronomía');

  doc.saveAndClose();

  const file = DriveApp.getFileById(doc.getId());
  try {
    const pdf = file.getAs(MimeType.PDF).setName('Solicitud_Bajas_' + corr + '.pdf');
    const result = {
      ok: true,
      correlativo: corr,
      nombreArchivo: pdf.getName(),
      base64: Utilities.base64Encode(pdf.getBytes())
    };
    file.setTrashed(true);
    return result;
  } catch (e) {
    file.setTrashed(true);
    throw e;
  }
}`;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-amber-600" />
            <h2 className="text-base font-bold text-slate-900">
              Exportar para Google Apps Script
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Descargue o copie el código optimizado de <strong className="text-slate-700">Index.html</strong> y <strong className="text-slate-700">Code.gs</strong> listo para reemplazar en su editor de Apps Script.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => downloadFile(MODERN_INDEX_HTML, 'Index.html')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-200"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Descargar Index.html</span>
          </button>

          <button
            onClick={() => downloadFile(CODE_GS, 'Code.gs')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-200"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Descargar Code.gs</span>
          </button>
        </div>
      </div>

      {/* Code Viewer Container */}
      <div className="bg-slate-900 rounded-xl overflow-hidden shadow-md border border-slate-800">
        {/* Tab Strip */}
        <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('index')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'index'
                  ? 'bg-[#00565b] text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Index.html (Frontend Modernizado)</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-[#00565b] text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Code.gs (Backend GAS)</span>
            </button>

            <button
              onClick={() => setActiveTab('instructions')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'instructions'
                  ? 'bg-[#00565b] text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Guía de Instalación</span>
            </button>
          </div>

          <div>
            {activeTab === 'index' && (
              <button
                onClick={() => copyToClipboard(MODERN_INDEX_HTML, 'index')}
                className="px-3 py-1 bg-teal-800/80 hover:bg-teal-700 text-teal-100 rounded text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copied === 'index' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied === 'index' ? '¡Copiado!' : 'Copiar Index.html'}</span>
              </button>
            )}

            {activeTab === 'code' && (
              <button
                onClick={() => copyToClipboard(CODE_GS, 'code')}
                className="px-3 py-1 bg-teal-800/80 hover:bg-teal-700 text-teal-100 rounded text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copied === 'code' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied === 'code' ? '¡Copiado!' : 'Copiar Code.gs'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Code Content */}
        {activeTab === 'index' && (
          <div className="p-4 max-h-[500px] overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed bg-slate-900">
            <pre>
              <code>{MODERN_INDEX_HTML}</code>
            </pre>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="p-4 max-h-[500px] overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed bg-slate-900">
            <pre>
              <code>{CODE_GS}</code>
            </pre>
          </div>
        )}

        {activeTab === 'instructions' && (
          <div className="p-6 text-sm text-slate-300 space-y-4 bg-slate-900">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Cómo actualizar su sistema en Google Apps Script:</span>
            </h3>

            <ol className="list-decimal list-inside space-y-3 text-xs leading-relaxed text-slate-300">
              <li>
                <strong className="text-white">Abra su proyecto en Google Apps Script:</strong> Ingrese a script.google.com y abra el proyecto de Inventario FAUSAC.
              </li>
              <li>
                <strong className="text-white">Actualice el archivo Index.html:</strong> Haga clic en la pestaña "Index.html" del editor de Apps Script, borre todo el contenido anterior y pegue el código de la pestaña <strong className="text-teal-300 font-mono">Index.html</strong> (o use el botón "Copiar Index.html").
              </li>
              <li>
                <strong className="text-white">Verifique su Code.gs:</strong> Asegúrese de que su archivo <strong className="text-teal-300 font-mono">Code.gs</strong> tenga configurado su <code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300">SPREADSHEET_ID</code> y en las propiedades del script la clave <code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300">GEMINI_API_KEY</code>.
              </li>
              <li>
                <strong className="text-white">Implementar nueva versión:</strong> Haga clic en el botón azul superior <strong className="text-emerald-400">Implementar &gt; Administrar implementaciones &gt; Editar &gt; Nueva versión &gt; Implementar</strong>.
              </li>
            </ol>

            <div className="mt-4 p-4 rounded-lg bg-teal-950/60 border border-teal-800/60 text-xs text-teal-200">
              ¡Listo! Su aplicación web en Google Apps Script lucirá moderna, con tipografía Plus Jakarta Sans, diseño institucional USAC FAUSAC, tarjetas interactivas y 100% conectada a su Google Sheet y Drive.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
