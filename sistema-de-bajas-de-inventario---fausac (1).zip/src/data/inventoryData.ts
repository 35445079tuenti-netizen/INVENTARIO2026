import { BienItem } from '../utils/pdfGenerator';

export interface InventarioRow extends BienItem {
  fila?: number;
  personal: string;
  nombre: string;
  primerNombre: string;
  departamento?: string;
}

export const INITIAL_INVENTORY_DATA: InventarioRow[] = [
  // Usuario: Víctor (RegPer: 20140273)
  {
    personal: '20140273',
    nombre: 'Víctor Manuel Morales Gómez',
    primerNombre: 'victor',
    departamento: 'Facultad de Agronomía',
    inventario: '2021-00812',
    descripcion: 'Computadora de escritorio Dell OptiPlex 7080 Core i7 con monitor 24" y accesorios',
    valor: '9200.00',
    tarjeta: 'TR-2021-140',
    ubicacion: 'Edificio T-8 · Facultad de Agronomía',
    estado: 'Inoperable / Tarjeta madre dañada',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },
  {
    personal: '20140273',
    nombre: 'Víctor Manuel Morales Gómez',
    primerNombre: 'victor',
    departamento: 'Facultad de Agronomía',
    inventario: '2019-00431',
    descripcion: 'Impresora láser multifuncional monocromática HP LaserJet Enterprise M507',
    valor: '3850.00',
    tarjeta: 'TR-2019-065',
    ubicacion: 'Edificio T-8 · Oficina de Docencia',
    estado: 'Dañada / Rodillo desalineado',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },
  {
    personal: '20140273',
    nombre: 'Víctor Manuel Morales Gómez',
    primerNombre: 'victor',
    departamento: 'Facultad de Agronomía',
    inventario: '2018-00914',
    descripcion: 'Silla ejecutiva ergonómica giratoria con soporte lumbar y reposabrazos',
    valor: '1150.00',
    tarjeta: 'TR-2018-072',
    ubicacion: 'Edificio T-8 · Cubículo de Trabajo',
    estado: 'Inservible / Estructura quebrada',
    procedencia: 'Presupuesto Ordinario',
    renglon: '328',
  },
  {
    personal: '20140273',
    nombre: 'Víctor Manuel Morales Gómez',
    primerNombre: 'victor',
    departamento: 'Facultad de Agronomía',
    inventario: '2020-00329',
    descripcion: 'Escritorio secretarial modular con gavetero metálico de 3 niveles',
    valor: '1450.00',
    tarjeta: 'TR-2020-019',
    ubicacion: 'Edificio T-8 · Facultad de Agronomía',
    estado: 'Regular / Desgaste por uso',
    procedencia: 'Presupuesto Ordinario',
    renglon: '328',
  },
  {
    personal: '20140273',
    nombre: 'Víctor Manuel Morales Gómez',
    primerNombre: 'victor',
    departamento: 'Facultad de Agronomía',
    inventario: '2017-00518',
    descripcion: 'Aire acondicionado portátil 12,000 BTU con ducto y control remoto',
    valor: '4200.00',
    tarjeta: 'TR-2017-088',
    ubicacion: 'Edificio T-8 · Área de Laboratorios',
    estado: 'Compresor dañado / Inservible',
    procedencia: 'Fondos Privativos',
    renglon: '324',
  },

  // Prof. Carlos Mendoza (RegPer: 10245)
  {
    personal: '10245',
    nombre: 'Carlos Mendoza Solórzano',
    primerNombre: 'carlos',
    departamento: 'Departamento de Fitotecnia',
    inventario: '2021-00452',
    descripcion: 'Computadora portátil Dell Latitude 5420 Core i7 16GB RAM con cargador',
    valor: '8450.00',
    tarjeta: 'TR-2021-089',
    ubicacion: 'Edificio T-8 · Laboratorio de Suelos',
    estado: 'Bueno',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },
  {
    personal: '10245',
    nombre: 'Carlos Mendoza Solórzano',
    primerNombre: 'carlos',
    departamento: 'Departamento de Fitotecnia',
    inventario: '2018-01120',
    descripcion: 'Microscopio binocular óptico Olympus CX23 con platina mecánica',
    valor: '12800.00',
    tarjeta: 'TR-2018-044',
    ubicacion: 'Edificio T-8 · Lab. Fitopatología',
    estado: 'Deteriorado / Óptica descalibrada',
    procedencia: 'Donación Cooperación Japonesa',
    renglon: '324',
  },
  {
    personal: '10245',
    nombre: 'Carlos Mendoza Solórzano',
    primerNombre: 'carlos',
    departamento: 'Departamento de Fitotecnia',
    inventario: '2019-00891',
    descripcion: 'Medidor portátil digital de pH y conductividad Hanna Instruments con electrodos',
    valor: '3650.00',
    tarjeta: 'TR-2019-102',
    ubicacion: 'Edificio T-9 · Campo Experimental',
    estado: 'Mal estado / Tarjeta lógica dañada',
    procedencia: 'Fondo de Investigación DIGI',
    renglon: '324',
  },
  {
    personal: '10245',
    nombre: 'Carlos Mendoza Solórzano',
    primerNombre: 'carlos',
    departamento: 'Departamento de Fitotecnia',
    inventario: '2017-00334',
    descripcion: 'Silla ejecutiva ergonómica giratoria con reposabrazos ajustables y pistón hidráulico',
    valor: '950.00',
    tarjeta: 'TR-2017-015',
    ubicacion: 'Oficina de Cátedra Depto. Fitotecnia',
    estado: 'Dañado / Pistón quebrado',
    procedencia: 'Presupuesto Ordinario',
    renglon: '328',
  },
  {
    personal: '10245',
    nombre: 'Carlos Mendoza Solórzano',
    primerNombre: 'carlos',
    departamento: 'Departamento de Fitotecnia',
    inventario: '2020-00612',
    descripcion: 'Estante metálico industrial de 5 entrepaños color gris martillado',
    valor: '1200.00',
    tarjeta: 'TR-2020-058',
    ubicacion: 'Archivo General de Agronomía',
    estado: 'Regular / Oxidación moderada',
    procedencia: 'Presupuesto Ordinario',
    renglon: '328',
  },

  // M.Sc. María Morales (RegPer: 10382)
  {
    personal: '10382',
    nombre: 'María Morales Estrada',
    primerNombre: 'maria',
    departamento: 'Centro de Investigaciones Agronómicas',
    inventario: '2020-01560',
    descripcion: 'Balanza analítica digital de alta precisión Ohaus Pioneer 0.0001g',
    valor: '9400.00',
    tarjeta: 'TR-2020-112',
    ubicacion: 'Laboratorio de Semillas T-8',
    estado: 'Mal estado / Celda de carga vencida',
    procedencia: 'Presupuesto Ordinario',
    renglon: '324',
  },
  {
    personal: '10382',
    nombre: 'María Morales Estrada',
    primerNombre: 'maria',
    departamento: 'Centro de Investigaciones Agronómicas',
    inventario: '2019-00214',
    descripcion: 'Impresora multifuncional láser monocromática HP LaserJet Pro 400',
    valor: '2850.00',
    tarjeta: 'TR-2019-087',
    ubicacion: 'Cubículo de Docencia T-2',
    estado: 'Inoperable / Fusor quemado',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },
  {
    personal: '10382',
    nombre: 'María Morales Estrada',
    primerNombre: 'maria',
    departamento: 'Centro de Investigaciones Agronómicas',
    inventario: '2021-00789',
    descripcion: 'GPS Receptor Navegador satelital de campo Garmin Montana 700 con batería',
    valor: '5300.00',
    tarjeta: 'TR-2021-033',
    ubicacion: 'Caseta de Investigación Sabana Grande',
    estado: 'Regular',
    procedencia: 'Proyecto FODECYT',
    renglon: '324',
  },

  // Lic. Jorge Ramos (RegPer: 10499)
  {
    personal: '10499',
    nombre: 'Jorge Ramos Castillo',
    primerNombre: 'jorge',
    departamento: 'Laboratorio de Biotecnología Vegetal',
    inventario: '2016-00105',
    descripcion: 'Espectrofotómetro UV-Vis Thermo Genesys 10S con cubetas de cuarzo',
    valor: '28500.00',
    tarjeta: 'TR-2016-012',
    ubicacion: 'Lab Central Agronomía Edificio T-8',
    estado: 'Inservible por obsolescencia tecnológica',
    procedencia: 'Convenio Internacional',
    renglon: '324',
  },
  {
    personal: '10499',
    nombre: 'Jorge Ramos Castillo',
    primerNombre: 'jorge',
    departamento: 'Laboratorio de Biotecnología Vegetal',
    inventario: '2018-00993',
    descripcion: 'Regulador de voltaje de potencia Forza 1200VA con supresor de picos',
    valor: '650.00',
    tarjeta: 'TR-2018-088',
    ubicacion: 'Lab Central Agronomía Edificio T-8',
    estado: 'Dañado / Transformador en corto',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },

  // Bienes adicionales para pruebas de búsqueda de bienes externos:
  {
    personal: '10118',
    nombre: 'Ana Lucía Castillo Méndez',
    primerNombre: 'ana',
    departamento: 'Área de Suelos y Agua',
    inventario: '2015-00412',
    descripcion: 'Centrífuga de mesa refrigerada Jouan CR3i con rotor angular para 24 tubos',
    valor: '14200.00',
    tarjeta: 'TR-2015-021',
    ubicacion: 'Almacén de Reactivos y Equipos',
    estado: 'Regular',
    procedencia: 'Fondos Privativos',
    renglon: '324',
  },
  {
    personal: '10560',
    nombre: 'Roberto Gómez Pineda',
    primerNombre: 'roberto',
    departamento: 'Estación Experimental Sabana Grande',
    inventario: '2019-00551',
    descripcion: 'Proyector multimedia digital Epson PowerLite 3200 lúmenes con cable HDMI',
    valor: '4900.00',
    tarjeta: 'TR-2019-014',
    ubicacion: 'Salón Audiovisual T-8-201',
    estado: 'Lámpara agotada / Obsoleto',
    procedencia: 'Presupuesto Ordinario',
    renglon: '322',
  },
  {
    personal: '10612',
    nombre: 'Silvia Santos Valenzuela',
    primerNombre: 'silvia',
    departamento: 'Laboratorio de Microbiología Agrícola',
    inventario: '2022-00999',
    descripcion: 'Autoclave vertical de esterilización a vapor 75 Litros con manómetro de seguridad',
    valor: '32000.00',
    tarjeta: 'TR-2022-001',
    ubicacion: 'Laboratorio de Biotecnología T-8',
    estado: 'En evaluación',
    procedencia: 'Consejo Superior Universitario',
    renglon: '324',
  },
];

const STORAGE_KEY = 'fausac_inventario_data_v2';
const CORRELATIVO_KEY = 'fausac_correlativo_counter_v2';

export function getStoredInventory(): InventarioRow[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Error loading inventory from localStorage', e);
  }
  return INITIAL_INVENTORY_DATA;
}

export function saveInventory(data: InventarioRow[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving inventory to localStorage', e);
  }
}

export function resetInventoryToDefault(): InventarioRow[] {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error(e);
  }
  return INITIAL_INVENTORY_DATA;
}

export function getNextCorrelativo(): string {
  const anio = new Date().getFullYear();
  let count = 1;
  try {
    const saved = localStorage.getItem(CORRELATIVO_KEY);
    if (saved) {
      count = parseInt(saved, 10) + 1;
    }
    localStorage.setItem(CORRELATIVO_KEY, String(count));
  } catch {
    count = Math.floor(Math.random() * 900) + 1;
  }
  return `SPB-${anio}-${String(count).padStart(5, '0')}`;
}
