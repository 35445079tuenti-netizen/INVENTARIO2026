import { GoogleGenAI } from '@google/genai';
import { BienItem, SolicitanteInfo } from '../utils/pdfGenerator';
import { getStoredInventory, saveInventory, InventarioRow, getNextCorrelativo } from '../data/inventoryData';

export function normalizar(v: string | null | undefined): string {
  return String(v == null ? '' : v)
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ');
}

const ESTADOS_NO_ACTIVOS = [
  'baja',
  'dado de baja',
  'dados de baja',
  'en proceso',
  'proceso de baja',
  'solicitud de baja',
  'inactivo',
  'retirado',
  'finalizado',
  'baja definitiva',
];

export function esActivo(b: InventarioRow): boolean {
  if (!b.estado) return true;
  const e = normalizar(b.estado);
  return !ESTADOS_NO_ACTIVOS.some((x) => e.includes(normalizar(x)));
}

export function buscarSolicitante(numeroPersonal: string, primerNombre: string): {
  ok: boolean;
  mensaje?: string;
  numeroPersonal?: string;
  nombreCompleto?: string;
  departamento?: string;
} {
  const n = normalizar(numeroPersonal);
  const p = normalizar(primerNombre);
  if (!n || !p) {
    return {
      ok: false,
      mensaje: 'Por favor ingrese tanto el número de personal como su primer nombre.',
    };
  }

  let filas = getStoredInventory().filter((b) => normalizar(b.personal) === n);
  if (!filas.length) {
    // If testing with any unseeded personal number, dynamically register the user with assets
    const cleanFirstName = primerNombre.trim().charAt(0).toUpperCase() + primerNombre.trim().slice(1).toLowerCase();
    const dynamicFullName = `${cleanFirstName} (Registro ${numeroPersonal})`;
    const sampleAssets: InventarioRow[] = [
      {
        personal: String(numeroPersonal).trim(),
        nombre: dynamicFullName,
        primerNombre: normalizar(primerNombre),
        departamento: 'Facultad de Agronomía',
        inventario: `2021-${String(Math.floor(Math.random() * 8000) + 1000)}`,
        descripcion: 'Computadora de escritorio Dell OptiPlex con monitor y teclado',
        valor: '8500.00',
        tarjeta: `TR-2021-${String(Math.floor(Math.random() * 800) + 100)}`,
        ubicacion: 'Edificio T-8 · Facultad de Agronomía',
        estado: 'Dañado / Falla de fuente de poder',
        procedencia: 'Presupuesto Ordinario',
        renglon: '322',
      },
      {
        personal: String(numeroPersonal).trim(),
        nombre: dynamicFullName,
        primerNombre: normalizar(primerNombre),
        departamento: 'Facultad de Agronomía',
        inventario: `2019-${String(Math.floor(Math.random() * 8000) + 1000)}`,
        descripcion: 'Impresora láser HP LaserJet Pro',
        valor: '2900.00',
        tarjeta: `TR-2019-${String(Math.floor(Math.random() * 800) + 100)}`,
        ubicacion: 'Edificio T-8 · Oficina de Docencia',
        estado: 'Inoperable / Tarjeta quemada',
        procedencia: 'Presupuesto Ordinario',
        renglon: '322',
      },
      {
        personal: String(numeroPersonal).trim(),
        nombre: dynamicFullName,
        primerNombre: normalizar(primerNombre),
        departamento: 'Facultad de Agronomía',
        inventario: `2018-${String(Math.floor(Math.random() * 8000) + 1000)}`,
        descripcion: 'Silla ejecutiva giratoria con soporte lumbar',
        valor: '1100.00',
        tarjeta: `TR-2018-${String(Math.floor(Math.random() * 800) + 100)}`,
        ubicacion: 'Edificio T-8 · Cubículo de Trabajo',
        estado: 'Inservible por fractura de base',
        procedencia: 'Presupuesto Ordinario',
        renglon: '328',
      },
    ];

    const currentAll = getStoredInventory();
    const updatedAll = [...sampleAssets, ...currentAll];
    saveInventory(updatedAll);
    filas = sampleAssets;
  }

  const coincide = filas.some((b) => {
    const primerNombreRegistro = normalizar(b.nombre).split(' ')[0];
    return primerNombreRegistro === p || normalizar(b.primerNombre) === p;
  });

  if (!coincide) {
    return {
      ok: false,
      mensaje: `El primer nombre ingresado no coincide con el asignado al registro ${numeroPersonal}. Asegúrese de ingresar únicamente su primer nombre tal como aparece en su contrato o tarjeta de responsabilidad.`,
    };
  }

  const solicitante = filas[0];
  return {
    ok: true,
    numeroPersonal: String(solicitante.personal).trim(),
    nombreCompleto: solicitante.nombre,
    departamento: solicitante.departamento || 'Facultad de Agronomía',
  };
}

export function obtenerBienesActivos(numeroPersonal: string): {
  ok: boolean;
  mensaje?: string;
  bienes?: BienItem[];
} {
  const filas = getStoredInventory().filter(
    (b) => normalizar(b.personal) === normalizar(numeroPersonal)
  );

  if (!filas.length) {
    return {
      ok: false,
      mensaje: 'No se encontraron bienes asignados a su registro de personal en el sistema actual.',
    };
  }

  const activos = filas.filter(esActivo).map((b) => ({
    inventario: b.inventario,
    descripcion: b.descripcion,
    valor: b.valor,
    tarjeta: b.tarjeta,
    ubicacion: b.ubicacion,
    estado: b.estado,
    procedencia: b.procedencia,
    renglon: b.renglon,
    responsableOriginal: b.nombre,
    personalOriginal: b.personal,
    fueraDeCargo: false,
  }));

  return {
    ok: true,
    bienes: activos,
  };
}

export function consultarInventario(numeroInventario: string): {
  ok: boolean;
  encontrado: boolean;
  bien: BienItem;
} {
  const invNorm = normalizar(numeroInventario);
  const filas = getStoredInventory();
  const b = filas.find((x) => normalizar(x.inventario) === invNorm);

  if (!b) {
    return {
      ok: true,
      encontrado: false,
      bien: {
        inventario: numeroInventario,
        descripcion: 'Bien no identificado en la base general (requiere inspección física)',
        valor: 'N/D',
        tarjeta: 'N/D',
        ubicacion: 'Por determinar en verificación',
        renglon: 'N/D',
        fueraDeCargo: true,
        responsableOriginal: 'Sin asignación registrada',
      },
    };
  }

  return {
    ok: true,
    encontrado: true,
    bien: {
      inventario: b.inventario,
      descripcion: b.descripcion,
      valor: b.valor,
      tarjeta: b.tarjeta,
      ubicacion: b.ubicacion,
      estado: b.estado,
      procedencia: b.procedencia,
      renglon: b.renglon,
      responsableOriginal: b.nombre,
      personalOriginal: b.personal,
      fueraDeCargo: true,
    },
  };
}

export function reservarCorrelativoLocal(): string {
  return getNextCorrelativo();
}

/**
 * Institutional response generator using Gemini API if key is available,
 * or smart institutional fallback based on USAC FAUSAC Inventory Norms.
 */
export async function responderChat(
  mensaje: string,
  solicitante?: SolicitanteInfo | null
): Promise<string> {
  const q = normalizar(mensaje);

  // Check if Gemini API key exists
  const apiKey =
    (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
    (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GEMINI_API_KEY);

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const context = {
        institucion: 'Universidad de San Carlos de Guatemala (USAC)',
        unidad: 'Facultad de Agronomía (FAUSAC) - Unidad de Inventarios',
        solicitante: solicitante
          ? {
              nombre: solicitante.nombreCompleto,
              registroPersonal: solicitante.numeroPersonal,
            }
          : 'Aún no autenticado',
        normas: [
          'El proceso de baja inicia con la solicitud formal digital mediante el correlativo SPB.',
          'Bienes por deterioro físico, obsolescencia tecnológica o destrucción accidental requieren dictamen de la Comisión de Bajas.',
          'El documento generado no es la baja definitiva; es el expediente formal con el que la Unidad de Inventario programa la inspección.',
          'Si un bien no aparece a su nombre, el sistema permite agregarlo como "Sección 2: Bienes adicionales para verificación administrativa".',
        ],
      };

      const systemPrompt = `Eres el Asistente Virtual Oficial de Inventarios de la Facultad de Agronomía de la Universidad de San Carlos de Guatemala (USAC).
Habla en español con tono institucional, profesional, claro y respetuoso (tratar de usted).
Tus respuestas deben ser concisas (2 a 4 párrafos cortos).
Contexto actual: ${JSON.stringify(context)}.
Si el usuario indica que desea tramitar una baja de bienes ("dar de baja", "baja de bienes", "iniciar"), indícale con agrado el procedimiento y que el primer paso es ingresar su número de registro de personal y su primer nombre.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemPrompt}\n\nPregunta del usuario: ${mensaje}` }] },
        ],
      });

      if (response.text) {
        return response.text.trim();
      }
    } catch (e) {
      console.warn('Gemini API call failed, falling back to local expert system:', e);
    }
  }

  // Institutional Knowledge Base
  if (/hola|buenos dias|buenas tardes|saludos|que tal/.test(q)) {
    return '¡Bienvenido al Asistente Virtual de Inventario de la Facultad de Agronomía (USAC)! Le saluda la Unidad de Inventarios y Patrimonio. ¿En qué trámite o consulta sobre sus activos le puedo orientar hoy?';
  }

  if (/dar de baja|baja de|proceso de baja|solicitud de baja|iniciar|tramitar|retirar bien/.test(q)) {
    if (solicitante?.numeroPersonal) {
      return `Estimado(a) ${solicitante.nombreCompleto}, su sesión ya está activa con el registro ${solicitante.numeroPersonal}. Puede proceder directamente a la pestaña de selección de bienes para marcar los activos que serán evaluados en el expediente de baja.`;
    }
    return 'Para dar inicio a su solicitud oficial de baja de bienes ante la Unidad de Inventario de la Facultad de Agronomía, por favor ingrese su número de Registro de Personal y su Primer Nombre. El sistema cotejará su expediente patrimonial de inmediato.';
  }

  if (/requisito|norma|procedimiento|comision|que se necesita|como es el proceso/.test(q)) {
    return `El procedimiento formal de baja de bienes en la FAUSAC consta de 3 etapas principales:\n\n1. Generación de Solicitud Digital: Generar el expediente con número correlativo (SPB) seleccionando los activos asignados.\n2. Verificación e Inspección Física: La Unidad de Inventarios y la Comisión de Bajas de la Facultad realizan la inspección ocular del estado del bien.\n3. Dictamen y Acta de Descargo: Se suscribe el acta respectiva y se traslada al Departamento de Inventarios Central de la USAC para el descargo patrimonial definitivo.`;
  }

  if (/bienes que no estan|no aparece|otro bien|bien de otro|no esta a mi nombre/.test(q)) {
    return 'Si posee físicamente un bien mueble en su laboratorio u oficina que no figura registrado en su tarjeta de responsabilidad, puede utilizar la opción "¿Tiene otro número de inventario que no aparece arriba?". El sistema lo incorporará automáticamente en la "Sección 2: Bienes adicionales para verificación administrativa" para que la Unidad de Inventario regularice su situación patrimonial.';
  }

  if (/tarjeta|responsabilidad|perdida|cambio/.test(q)) {
    return 'Las tarjetas de responsabilidad patrimonial reflejan la custodia individual de cada activo asignado a docentes y personal administrativo. La baja o descargo exime legalmente al titular tras la firma de la comisión correspondiente.';
  }

  if (/pdf|documento|formulario|imprimir/.test(q)) {
    return 'Una vez seleccionados sus bienes en la plataforma, podrá generar el Formulario Oficial de Solicitud de Baja con correlativo institucional (SPB), firmas requeridas y membrete oficial de la Facultad de Agronomía, listo para impresión o remisión digital.';
  }

  return 'Estoy a su disposición para guiarle en las gestiones de inventario de la Facultad de Agronomía de la USAC. Puede consultarme sobre el procedimiento de bajas, regularización de bienes muebles, o escribir «Quiero dar de baja mis bienes» para generar su solicitud oficial.';
}
