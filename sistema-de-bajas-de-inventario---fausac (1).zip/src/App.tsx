import React, { useState } from 'react';
import { Header } from './components/Header';
import { ChatAssistant } from './components/ChatAssistant';
import { GoodsSelector } from './components/GoodsSelector';
import { ReviewPanel } from './components/ReviewPanel';
import { SolicitanteInfo, BienItem } from './utils/pdfGenerator';
import {
  MessageSquare,
  CheckSquare,
  FileText,
  ShieldCheck,
  Building,
  ArrowRight,
  HelpCircle,
  AlertCircle,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'goods' | 'review'>('chat');
  const [solicitante, setSolicitante] = useState<SolicitanteInfo | null>(null);
  const [cargoGoods, setCargoGoods] = useState<BienItem[]>([]);
  const [extraGoods, setExtraGoods] = useState<BienItem[]>([]);
  const [selectedMap, setSelectedMap] = useState<Map<string, BienItem>>(new Map());

  // Called when applicant is verified in chat
  const handleGoodsLoaded = (goods: BienItem[]) => {
    setCargoGoods(goods);
    setExtraGoods([]);
    // By default, select all cargo goods for convenience
    const newMap = new Map<string, BienItem>();
    goods.forEach((b) => newMap.set(String(b.inventario), b));
    setSelectedMap(newMap);
  };

  const handleReset = () => {
    setSolicitante(null);
    setCargoGoods([]);
    setExtraGoods([]);
    setSelectedMap(new Map());
    setActiveTab('chat');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-slate-900">
      {/* Institutional Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onReset={handleReset}
        solicitanteName={solicitante?.nombreCompleto}
        selectedCount={selectedMap.size}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:py-8">
        {/* Workflow Progress Breadcrumb Bar */}
        <div className="mb-6 bg-white border border-slate-200 rounded-xl p-3 sm:p-4 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <span className="text-slate-500 font-semibold uppercase tracking-wider text-[11px] mr-1">
                Etapas del Trámite:
              </span>

              <button
                onClick={() => setActiveTab('chat')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'chat'
                    ? 'bg-[#00565b] text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>1. Orientación e Identificación</span>
              </button>

              <span className="text-slate-300">/</span>

              <button
                onClick={() => setActiveTab('goods')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'goods'
                    ? 'bg-[#00565b] text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <CheckSquare className="w-3.5 h-3.5" />
                <span>2. Selección de Bienes ({selectedMap.size})</span>
              </button>

              <span className="text-slate-300">/</span>

              <button
                onClick={() => setActiveTab('review')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'review'
                    ? 'bg-[#00565b] text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>3. Expediente y PDF Oficial</span>
              </button>
            </div>

            <div className="flex items-center gap-3 text-slate-500">
              {solicitante ? (
                <div className="flex items-center gap-1.5 text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    Solicitante: <strong>{solicitante.nombreCompleto}</strong> (Reg: {solicitante.numeroPersonal})
                  </span>
                </div>
              ) : (
                <span className="text-slate-500 italic">Identificación pendiente de ingresar</span>
              )}
            </div>
          </div>
        </div>

        {/* Tab Content Panels */}
        {activeTab === 'chat' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Main Column: Interactive Chat */}
            <div className="lg:col-span-8">
              <ChatAssistant
                solicitante={solicitante}
                setSolicitante={setSolicitante}
                onGoodsLoaded={handleGoodsLoaded}
                onGoToGoods={() => setActiveTab('goods')}
              />
            </div>

            {/* Right Information & Instructions Column for Applicants */}
            <div className="lg:col-span-4 space-y-4">
              {/* Applicant Guide Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
                <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <Building className="w-4 h-4 text-[#00565b]" />
                  <span>Facultad de Agronomía · FAUSAC</span>
                </h3>
                <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                  <p>
                    Bienvenido al sistema digital de bajas patrimoniales. Como docente, investigador o personal administrativo a cargo de bienes muebles, este asistente le guiará para emitir su expediente oficial de solicitud.
                  </p>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                    <strong className="text-slate-800 block">Flujo de Solicitud:</strong>
                    <div>1. Indique su Registro de Personal y Primer Nombre.</div>
                    <div>2. Revise y marque los bienes asignados a su cargo.</div>
                    <div>3. Agregue inventarios adicionales si los tiene físicamente.</div>
                    <div>4. Genere y descargue el PDF oficial para firmas.</div>
                  </div>
                </div>

                {solicitante && (
                  <button
                    onClick={() => setActiveTab('goods')}
                    className="mt-4 w-full py-2 bg-[#00565b] hover:bg-[#004145] text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Continuar a Selección de Bienes</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Legal Notice for Applicants */}
              <div className="bg-amber-50/50 rounded-xl border border-amber-200/80 p-4 text-xs text-amber-950">
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Normativa Patrimonial USAC:</span>
                </div>
                <p className="leading-relaxed text-[11px] text-amber-900">
                  La emisión de la solicitud digital genera el correlativo oficial (SPB) necesario para que la Unidad de Inventarios programe la inspección ocular. Los activos permanecen bajo custodia del solicitante hasta la firma del acta de descargo de la Comisión de Bajas.
                </p>
              </div>

              {/* Help Information Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800 mb-1">
                  <HelpCircle className="w-4 h-4 text-teal-700" />
                  <span>¿Dudas sobre su expediente?</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Puede consultar en cualquier momento dentro del chat sobre normativas, o dirigirse a la Unidad de Inventario en el Edificio T-8 de la Facultad de Agronomía.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'goods' && (
          <GoodsSelector
            solicitante={solicitante}
            cargoGoods={cargoGoods}
            extraGoods={extraGoods}
            setExtraGoods={setExtraGoods}
            selectedMap={selectedMap}
            setSelectedMap={setSelectedMap}
            onContinueToReview={() => setActiveTab('review')}
            onGoToChat={() => setActiveTab('chat')}
          />
        )}

        {activeTab === 'review' && (
          <ReviewPanel
            solicitante={solicitante}
            selectedMap={selectedMap}
            onBackToGoods={() => setActiveTab('goods')}
            onReset={handleReset}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <span className="font-bold text-slate-800">
              Universidad de San Carlos de Guatemala · USAC
            </span>
            <span className="mx-2 text-slate-300">|</span>
            <span>Facultad de Agronomía · Unidad de Inventario</span>
          </div>
          <div className="text-slate-400">
            Edificio T-8 · Ciudad Universitaria, Zona 12, Ciudad de Guatemala
          </div>
        </div>
      </footer>
    </div>
  );
}
